# Trading Ahead no AWS Glue (Python Shell)

O passo a passo completo está no guia em PDF (`guia/`). Este arquivo é o resumo para quem só vai subir o pacote.

## O que subir no bucket `itau-self-wkp-sa-east-1-886436964833`

| Arquivo do pacote | Destino no S3 |
| --- | --- |
| `scripts/main_trading_ahead.py` | `TRADING_AHEAD/scripts/main_trading_ahead.py` |
| `sql/*.sql` (25 arquivos) | `TRADING_AHEAD/sql/` |

As pastas `TRADING_AHEAD/ctas/<ambiente>/`, `TRADING_AHEAD/temp/` e `TRADING_AHEAD/logs/<ambiente>/` são preenchidas pelo job.

## Job no Glue

Python Shell, Python 3.9, "Load common analytics libraries" marcado, mesma role do Cripto, 1 DPU,
Script path `s3://itau-self-wkp-sa-east-1-886436964833/TRADING_AHEAD/scripts/`,
Temporary path `s3://itau-self-wkp-sa-east-1-886436964833/TRADING_AHEAD/temp/`,
Maximum concurrency 1, retries 0, sem bibliotecas adicionais.

Parâmetros de homologação: `--AMBIENTE hml --MODO plano --SAFRA 202509` (primeira vez) e depois `--MODO executar`.
Parâmetros de produção: `--AMBIENTE prd --MODO executar` sem `--SAFRA` (processa o mês anterior; só a partir do dia 8),
agendado com `cron(0 12 10 * ? *)`.

## Pastas do pacote

- `scripts/` o orquestrador (único script do job).
- `sql/` as 20 CTAs originais com banco, prefixo e caminho parametrizados, mais 5 SQLs curtas (PF/PJ, base do P99 e alertas finais).
- `testes/` o ambiente de teste usado na validação (Trino local como Athena, dados simulados, verificações).
- `guia/` o guia em PDF.
