"""Trading Ahead: orquestrador do job AWS Glue (Python Shell 3.9, bibliotecas "analytics").

O que este script faz, em ordem:
  1. Lê as SQLs da pasta sql/ do bucket e troca os parâmetros da safra ({{SAFRA}}, datas, banco e caminho).
  2. Para cada safra do histórico de 182 dias e para a safra alvo, roda a cadeia base (CTA1 a CTA13 base)
     no Athena, sempre com DROP TABLE + limpeza do destino + CTAS. Safras do histórico que já têm a
     CTA13 base calculada são reaproveitadas (use --RECALCULAR_HISTORICO true para refazer).
  3. Calcula o P99 exato do resultado por público (PF e PJ), com piso de R$ 100 mil.
  4. Roda as CTAs finais da safra alvo (CTA13 PF/PJ, CTA14 a CTA19) e grava os alertas que passam no corte.
  5. Registra tudo em log_resumo e log_detalhe (Parquet, partição safra) na pasta logs/ do bucket,
     além de linhas JSON no CloudWatch e um JSON por execução em logs/<ambiente>/execucoes/.

Parâmetros do job (Glue > Job details > Job parameters). Só --AMBIENTE é obrigatório:
  --AMBIENTE              hml | prd
  --MODO                  plano | executar          (padrão: plano, que só gera as SQLs em temp/plano/)
  --SAFRA                 AAAAMM | auto             (padrão: auto, que usa o mês anterior ao da execução)
  --BUCKET                padrão: itau-self-wkp-sa-east-1-886436964833
  --PASTA                 padrão: TRADING_AHEAD
  --DATABASE              padrão: workspace_db
  --WORKGROUP             padrão: consumer-workgroup-market-surveillance
  --REGIAO                padrão: sa-east-1
  --RECALCULAR_HISTORICO  true | false              (padrão: false)
  --DIAGNOSTICOS_FONTES   true | false              (padrão: true)
"""
import calendar
import importlib.metadata
import json
import math
import platform
import re
import sys
import time
import traceback
import uuid
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

# ----------------------------------------------------------------------------------------------
# Regra aprovada e padrão de logs (mesmos nomes, colunas e tipos do script original)
# ----------------------------------------------------------------------------------------------
POLICY_VERSION = "p99_piso100k_182d_v2"
OBSERVABILITY_VERSION = "cripto_logs_adaptados_ta_v2"
DIAS_HISTORICO = 182
PERCENTIL = 0.99
PISO_BRL = 100000.0
FUSO_BRASIL = timezone(timedelta(hours=-3))  # Brasil sem horário de verão desde 2019

ETAPAS_BASE = ["cta01", "cta02", "cta03", "cta04", "cta05", "cta06",
               "cta07", "cta08", "cta09", "cta10", "cta11", "cta13_base"]
ETAPAS_FINAIS = ["cta13_pf", "cta13_pj", "cta14", "cta15", "cta16", "cta17",
                 "cta18", "cta18_alertas", "cta19"]
ETAPAS_ALERTAS = ["alertas_pf_vinculos", "alertas_pf", "alertas_pj_vinculos", "alertas_pj"]
TABELA_BASE_P99 = "CTA13_CalculoResultado_Base_Estudo"
ORIGEM_ALERTAS = {"PF": "CTA18_AlertasTradingAhead_PF", "PJ": "CTA19_ProxyReversaoCustodia"}

CHAVE_ALERTA = (
    "codigo_cliente", "cpf_cnpj_cliente", "ativo_negociado", "ativo_negociado_4letras",
    "tipo_pessoa", "origem_operacao", "data_evento",
    "soma_quantidade_compra_historica", "soma_quantidade_venda_historica",
    "soma_quantidade_compra_15dias", "soma_quantidade_venda_15dias",
    "quantidade_compra_d0", "quantidade_venda_d0",
    "soma_quantidade_compra_5diasdepois", "soma_quantidade_venda_5diasdepois",
    "resultado", "diferenca_volume",
)

COLS_LOG_RESUMO = ["data_execucao", "safra", "tipo_verificacao", "coluna", "lado_avaliado",
                   "n_afetados", "total_avaliado", "pct", "tolerancia_pct", "acao"]
COLS_LOG_DETALHE = ["data_execucao", "safra", "tipo_verificacao", "coluna",
                    "entidade_tipo", "entidade_id", "detalhe"]
DTYPE_LOG_RESUMO = {"data_execucao": "timestamp", "tipo_verificacao": "string", "coluna": "string",
                    "lado_avaliado": "string", "n_afetados": "bigint", "total_avaliado": "bigint",
                    "pct": "double", "tolerancia_pct": "double", "acao": "string"}
DTYPE_LOG_DETALHE = {"data_execucao": "timestamp", "tipo_verificacao": "string", "coluna": "string",
                     "entidade_tipo": "string", "entidade_id": "string", "detalhe": "string"}
EXTRA_LOG_TYPES = {"id_execucao": "string", "id_tentativa": "string", "etapa": "string",
                   "publico": "string", "query_id": "string", "tempo_total_s": "double",
                   "bytes_lidos": "bigint"}

PADROES = {"MODO": "plano", "SAFRA": "auto", "BUCKET": "itau-self-wkp-sa-east-1-886436964833",
           "PASTA": "TRADING_AHEAD", "DATABASE": "workspace_db",
           "WORKGROUP": "consumer-workgroup-market-surveillance", "REGIAO": "sa-east-1",
           "RECALCULAR_HISTORICO": "false", "DIAGNOSTICOS_FONTES": "true", "MAX_DETALHES": "100"}
TEMPO_MAXIMO_CONSULTA_S = 3600
INTERVALO_CONSULTA_S = 3


class ErroExecucao(RuntimeError):
    """Falha prevista pelo orquestrador; a mensagem diz a etapa e o motivo."""


def emit(evento, **campos):
    """Linha JSON no stdout (CloudWatch /aws-glue/python-jobs/output)."""
    print(json.dumps({"timestamp": datetime.now(timezone.utc).isoformat(), "event": evento, **campos},
                     ensure_ascii=False, sort_keys=True, default=str), flush=True)


def descrever_erro(erro):
    """Tipo, mensagem e onde aconteceu (arquivo, linha e função), para os logs."""
    return {"error_type": type(erro).__name__, "mensagem": str(erro)[:1500],
            "frames": [{"arquivo": Path(f.filename).name, "linha": f.lineno, "funcao": f.name}
                       for f in traceback.extract_tb(erro.__traceback__)[-8:]]}


# ----------------------------------------------------------------------------------------------
# Parâmetros e datas
# ----------------------------------------------------------------------------------------------
def ler_argumentos(argv):
    """Lê pares --CHAVE valor. Parâmetros que o próprio Glue envia (JOB_ID, TempDir...) são ignorados."""
    args, i = {}, 1
    while i < len(argv):
        item = argv[i]
        if not item.startswith("--"):
            i += 1
            continue
        chave = item[2:]
        if "=" in chave:
            chave, valor = chave.split("=", 1)
            i += 1
        elif i + 1 < len(argv) and not argv[i + 1].startswith("--"):
            valor, i = argv[i + 1], i + 2
        else:
            valor, i = "true", i + 1
        args[chave.strip()] = valor.strip()
    return args


def limites_mes(safra):
    if not re.fullmatch(r"20\d{2}(0[1-9]|1[0-2])", str(safra)):
        raise ValueError("SAFRA deve estar no formato AAAAMM, por exemplo 202509.")
    ano, mes = int(safra[:4]), int(safra[4:])
    return date(ano, mes, 1), date(ano, mes, calendar.monthrange(ano, mes)[1])


def janela_historica(safra):
    inicio, _ = limites_mes(safra)
    return inicio - timedelta(days=DIAS_HISTORICO), inicio - timedelta(days=1)


def meses_historico(safra):
    baixo, alto = janela_historica(safra)
    cursor, meses = baixo.replace(day=1), []
    while cursor <= alto:
        meses.append(cursor.strftime("%Y%m"))
        cursor = date(cursor.year + (cursor.month == 12), cursor.month % 12 + 1, 1)
    return meses


def booleano(nome, valor):
    if str(valor).lower() not in ("true", "false"):
        raise ValueError(nome + " deve ser true ou false.")
    return str(valor).lower() == "true"


def configurar(argv, agora=None):
    args = ler_argumentos(argv)
    cfg = dict(PADROES, **{k: v for k, v in args.items() if k in PADROES or k == "AMBIENTE"})
    agora = agora or datetime.now(FUSO_BRASIL)
    if cfg.get("AMBIENTE") not in ("hml", "prd"):
        raise ValueError("Informe --AMBIENTE hml (teste) ou --AMBIENTE prd (produção).")
    if cfg["MODO"] not in ("plano", "executar"):
        raise ValueError("--MODO deve ser plano ou executar.")
    if cfg["SAFRA"] == "auto":
        primeiro_dia = agora.date().replace(day=1)
        cfg["SAFRA"] = (primeiro_dia - timedelta(days=1)).strftime("%Y%m")
        cfg["SAFRA_AUTOMATICA"] = True
    else:
        cfg["SAFRA_AUTOMATICA"] = False
    _, fim = limites_mes(cfg["SAFRA"])
    # CTA1/CTA6 leem até o fim do mês + 7 dias: a safra só está madura depois disso.
    if agora.date() <= fim + timedelta(days=7):
        raise ValueError("A safra " + cfg["SAFRA"] + " só pode rodar a partir de "
                         + (fim + timedelta(days=8)).isoformat() + " (fontes precisam de fim do mês + 7 dias).")
    for nome, padrao in (("BUCKET", r"[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]"), ("PASTA", r"[A-Za-z0-9_./-]+"),
                         ("DATABASE", r"[a-z][a-z0-9_]*"), ("WORKGROUP", r"[A-Za-z0-9._-]+"),
                         ("REGIAO", r"[a-z]{2}-[a-z]+-\d"), ("MAX_DETALHES", r"\d{1,4}")):
        if not re.fullmatch(padrao, str(cfg[nome])):
            raise ValueError("Parâmetro --" + nome + " inválido.")
    cfg["PASTA"] = cfg["PASTA"].strip("/")
    cfg["RECALCULAR_HISTORICO"] = booleano("RECALCULAR_HISTORICO", cfg["RECALCULAR_HISTORICO"])
    cfg["DIAGNOSTICOS_FONTES"] = booleano("DIAGNOSTICOS_FONTES", cfg["DIAGNOSTICOS_FONTES"])
    cfg["MAX_DETALHES"] = int(cfg["MAX_DETALHES"])
    base = "s3://" + cfg["BUCKET"] + "/" + cfg["PASTA"] + "/"
    cfg["S3_CTAS"] = base + "ctas/" + cfg["AMBIENTE"] + "/"
    cfg["S3_LOGS"] = base + "logs/" + cfg["AMBIENTE"] + "/"
    cfg["S3_TEMP"] = base + "temp/"
    cfg["CHAVE_SQL"] = cfg["PASTA"] + "/sql/"
    cfg["PREFIXO_TABELA"] = cfg["AMBIENTE"] + "_"
    cfg["ID_EXECUCAO"] = (cfg["AMBIENTE"] + "_" + cfg["SAFRA"] + "_" + agora.strftime("%Y%m%dt%H%M%S")).lower()
    cfg["ID_TENTATIVA"] = args.get("JOB_RUN_ID") or ("local_" + uuid.uuid4().hex[:12])
    cfg["JOB_NAME"] = args.get("JOB_NAME")
    return cfg


# ----------------------------------------------------------------------------------------------
# P99 exato (mesma interpolação linear do numpy.quantile)
# ----------------------------------------------------------------------------------------------
def posicoes_p99(n):
    if type(n) is not int or n < 1:
        raise ErroExecucao("P99 indefinido: amostra histórica vazia.")
    posicao = (n - 1) * PERCENTIL
    inferior, superior = math.floor(posicao), math.ceil(posicao)
    return inferior + 1, superior + 1, posicao - inferior


def interpolar_p99(valor_inferior, valor_superior, n):
    _, _, peso = posicoes_p99(n)
    baixo, alto = float(valor_inferior), float(valor_superior)
    if not (math.isfinite(baixo) and math.isfinite(alto)) or baixo > alto:
        raise ErroExecucao("Valores de interpolação do P99 inválidos.")
    delta = alto - baixo
    return alto - delta * (1.0 - peso) if peso >= 0.5 else baixo + delta * peso


# ----------------------------------------------------------------------------------------------
# AWS: Athena, S3 e Glue (somente chamadas disponíveis no boto3 do Python Shell 3.9)
# ----------------------------------------------------------------------------------------------
def separar_s3(uri):
    sem_esquema = uri[len("s3://"):]
    bucket, _, chave = sem_esquema.partition("/")
    return bucket, chave


class Aws:
    def __init__(self, cfg):
        sdk = Config(retries={"max_attempts": 10, "mode": "standard"}, connect_timeout=10, read_timeout=60)
        self.cfg = cfg
        self.athena = boto3.client("athena", region_name=cfg["REGIAO"], config=sdk)
        self.s3 = boto3.client("s3", region_name=cfg["REGIAO"], config=sdk)
        self.glue = boto3.client("glue", region_name=cfg["REGIAO"], config=sdk)
        self.resultado_athena = {"OutputLocation": cfg["S3_TEMP"] + "athena/" + cfg["ID_EXECUCAO"] + "/"}

    def ler_texto(self, chave):
        corpo = self.s3.get_object(Bucket=self.cfg["BUCKET"], Key=chave)["Body"]
        try:
            return corpo.read().decode("utf-8")
        finally:
            corpo.close()

    def gravar_texto(self, uri, texto, tipo="text/plain; charset=utf-8"):
        bucket, chave = separar_s3(uri)
        self.s3.put_object(Bucket=bucket, Key=chave, Body=texto.encode("utf-8"), ContentType=tipo)

    def limpar_destino(self, uri):
        """Apaga os arquivos do destino de uma CTA antes do CTAS (o Athena exige pasta vazia)."""
        if not uri.startswith(self.cfg["S3_CTAS"]) or len(uri) <= len(self.cfg["S3_CTAS"]):
            raise ErroExecucao("Destino fora de " + self.cfg["S3_CTAS"] + "; nada foi apagado: " + uri)
        bucket, prefixo = separar_s3(uri)
        apagados = 0
        while True:  # lista de novo a cada volta até a pasta ficar vazia
            chaves = [{"Key": item["Key"]} for item in
                      self.s3.list_objects_v2(Bucket=bucket, Prefix=prefixo).get("Contents", [])]
            if not chaves:
                return apagados
            resposta = self.s3.delete_objects(Bucket=bucket, Delete={"Objects": chaves[:1000], "Quiet": True})
            if resposta.get("Errors"):  # o S3 devolve falha por arquivo sem levantar exceção
                falha = resposta["Errors"][0]
                raise ErroExecucao("Não foi possível apagar " + str(falha.get("Key")) + " antes do CTAS: "
                                   + str(falha.get("Code")) + " " + str(falha.get("Message", "")))
            apagados += len(chaves[:1000])

    def tabela_existe(self, nome):
        try:
            self.glue.get_table(DatabaseName=self.cfg["DATABASE"], Name=nome.lower())
            return True
        except ClientError as erro:
            if erro.response.get("Error", {}).get("Code") == "EntityNotFoundException":
                return False
            raise

    def checar_workgroup(self):
        """Lê a configuração do workgroup: motor, se força as configurações e a criptografia dos resultados."""
        try:
            grupo = self.athena.get_work_group(WorkGroup=self.cfg["WORKGROUP"])["WorkGroup"]
        except ClientError as erro:
            return {"aviso": "sem permissão para ler o workgroup: " + erro.response.get("Error", {}).get("Code", "")}
        conf = grupo.get("Configuration", {})
        cripto = conf.get("ResultConfiguration", {}).get("EncryptionConfiguration")
        if cripto:
            self.resultado_athena["EncryptionConfiguration"] = cripto
        info = {"estado": grupo.get("State"),
                "motor": conf.get("EngineVersion", {}).get("EffectiveEngineVersion"),
                "forca_configuracao": bool(conf.get("EnforceWorkGroupConfiguration")),
                "saida_padrao": conf.get("ResultConfiguration", {}).get("OutputLocation"),
                "criptografia": (cripto or {}).get("EncryptionOption")}
        if info["forca_configuracao"]:
            raise ErroExecucao("O workgroup " + self.cfg["WORKGROUP"] + " está com 'Override client-side settings' ligado. "
                               "Nesse caso o Athena recusa CTAS com external_location. Use o workgroup do notebook "
                               "original ou peça para desligar essa opção.")
        return info


# ----------------------------------------------------------------------------------------------
# Logs: log_resumo e log_detalhe, mesmo padrão do script original (Cripto)
# ----------------------------------------------------------------------------------------------
class LogBook:
    def __init__(self, cfg, aws):
        self.cfg, self.aws = cfg, aws
        self.resumos, self.detalhes = [], []
        self.etapa_atual = "inicializacao"
        self.lotes = 0

    def _comum(self, etapa=None, safra=None, publico=None, query_id=None, tempo=None, bytes_lidos=None):
        return {"data_execucao": datetime.now(timezone.utc).isoformat(), "safra": safra or self.cfg["SAFRA"],
                "id_execucao": self.cfg["ID_EXECUCAO"], "id_tentativa": self.cfg["ID_TENTATIVA"],
                "etapa": etapa or self.etapa_atual, "publico": publico, "query_id": query_id,
                "tempo_total_s": None if tempo is None else round(float(tempo), 3), "bytes_lidos": bytes_lidos}

    def resumo(self, tipo, coluna="-", afetados=0, total=0, acao="ok", lado="ambos", tolerancia=None, **contexto):
        linha = self._comum(**contexto)
        linha.update(tipo_verificacao=tipo, coluna=coluna, lado_avaliado=lado, n_afetados=int(afetados),
                     total_avaliado=int(total), pct=round(100.0 * afetados / total, 4) if total else 0.0,
                     tolerancia_pct=tolerancia, acao=acao)
        self.resumos.append(linha)
        emit("log_resumo", **{k: linha[k] for k in ("safra", "etapa", "tipo_verificacao", "coluna",
                                                     "n_afetados", "total_avaliado", "acao", "query_id")})
        return linha

    def detalhe(self, tipo, entidade_tipo, entidade_id, detalhe, coluna="-", **contexto):
        linha = self._comum(**contexto)
        linha.update(tipo_verificacao=tipo, coluna=coluna, entidade_tipo=entidade_tipo,
                     entidade_id=str(entidade_id),
                     detalhe=json.dumps(detalhe, ensure_ascii=False, sort_keys=True, default=str))
        self.detalhes.append(linha)
        return linha

    def gravar(self):
        """Grava o que está acumulado em Parquet (append, partição safra) e registra no Glue Catalog."""
        if not self.resumos and not self.detalhes:
            return
        import awswrangler as wr
        import pandas as pd
        sessao = boto3.Session(region_name=self.cfg["REGIAO"])
        try:
            for tipo, linhas, colunas, tipos in (
                    ("resumo", self.resumos, COLS_LOG_RESUMO, dict(DTYPE_LOG_RESUMO, **EXTRA_LOG_TYPES)),
                    ("detalhe", self.detalhes, COLS_LOG_DETALHE, dict(DTYPE_LOG_DETALHE, **EXTRA_LOG_TYPES))):
                if not linhas:
                    continue
                df = pd.DataFrame(linhas, columns=colunas + list(EXTRA_LOG_TYPES))
                df["safra"] = df["safra"].astype("string")
                for coluna, tipo_athena in tipos.items():
                    if tipo_athena == "string":
                        df[coluna] = df[coluna].astype("string")
                    elif tipo_athena == "bigint":
                        df[coluna] = pd.to_numeric(df[coluna]).astype("Int64")
                    elif tipo_athena == "double":
                        df[coluna] = pd.to_numeric(df[coluna]).astype("Float64")
                    else:
                        df[coluna] = pd.to_datetime(df[coluna], utc=True).dt.tz_localize(None)
                wr.s3.to_parquet(df=df, path=self.cfg["S3_LOGS"] + "log_" + tipo + "/", dataset=True,
                                 mode="append", database=self.cfg["DATABASE"],
                                 table="trading_ahead_" + self.cfg["AMBIENTE"] + "_log_" + tipo,
                                 partition_cols=["safra"], dtype=tipos, index=False,
                                 compression="snappy", boto3_session=sessao)
        except Exception as erro:
            # Nada se perde: as linhas vão para o CloudWatch antes de a falha subir.
            for linha in self.resumos + self.detalhes:
                emit("log_nao_persistido", **linha)
            emit("log_persistence_failed", **descrever_erro(erro))
            self.resumos, self.detalhes = [], []  # já estão no CloudWatch; evita repetir na próxima tentativa
            raise
        emit("logs_persistidos", id_execucao=self.cfg["ID_EXECUCAO"], lote=self.lotes,
             resumo=len(self.resumos), detalhe=len(self.detalhes))
        self.resumos, self.detalhes = [], []
        self.lotes += 1


# ----------------------------------------------------------------------------------------------
# Diagnósticos das fontes (observacionais: não mudam nenhum filtro das CTAs)
# ----------------------------------------------------------------------------------------------
def _metrica(tipo, coluna, condicao):
    return {"kind": tipo, "column": coluna, "condition": condicao}


def especificacao_fonte(etapa, safra, tabela_cta05):
    primeiro, ultimo = limites_mes(safra)
    if etapa == "cta01":
        baixo, alto = primeiro - timedelta(days=365), ultimo + timedelta(days=7)
        fonte = "db_corp_gestaoderiscos_distribuiprecoscorporativos_sor_01.tbim8_acao_btres"
        relacao = (f"{fonte} WHERE idt_atbt = '11' AND nom_font_info = 'B3' "
                   f"AND CAST(dat_base_info AS VARCHAR) BETWEEN '{baixo:%Y%m%d}' AND '{alto:%Y%m%d}'")
        data = "TRY(DATE_PARSE(SUBSTR(CAST(dat_base_info AS VARCHAR), 1, 8), '%Y%m%d'))"
        metricas = [
            _metrica("nulo", "nom_ativ_finn", "nom_ativ_finn IS NULL"),
            _metrica("tipo_dado", "dat_base_info", f"dat_base_info IS NOT NULL AND {data} IS NULL"),
            _metrica("nulo", "vlr_atbt", "vlr_atbt IS NULL"),
            _metrica("tipo_dado", "vlr_atbt", "vlr_atbt IS NOT NULL AND TRY_CAST(vlr_atbt AS DOUBLE) IS NULL"),
            _metrica("nao_finito", "vlr_atbt", "TRY_CAST(vlr_atbt AS DOUBLE) IS NOT NULL AND NOT is_finite(TRY_CAST(vlr_atbt AS DOUBLE))"),
            _metrica("valor_nao_positivo", "vlr_atbt", "TRY_CAST(vlr_atbt AS DOUBLE) <= 0"),
            _metrica("tipo_dado", "timestamp", "TRY_CAST(COALESCE(NULLIF(CAST(timestamp AS VARCHAR), ''), '0') AS DOUBLE) IS NULL"),
            _metrica("tipo_dado", "versao", "TRY_CAST(COALESCE(NULLIF(CAST(versao AS VARCHAR), ''), '0') AS BIGINT) IS NULL"),
        ]
        return {"relation": relacao, "metrics": metricas, "entity": "nom_ativ_finn", "entity_type": "ativo",
                "scope": "B3 fechamento, antes do filtro de ativo.",
                "duplicate_key": ["dat_base_info", "nom_ativ_finn"], "duplicate_kind": "versoes_preco",
                "duplicate_note": "Repetições podem representar versões; a seleção oficial usa timestamp/versão."}
    baixo, alto = primeiro - timedelta(days=150), ultimo + timedelta(days=7)
    fonte = "db_corp_corretora_inoabrokertools_sot_01.tb_ep7_alocacoes_sot"
    data = "TRY_CAST(SUBSTR(CAST(data_pregao AS VARCHAR), 1, 10) AS DATE)"
    particao = "CONCAT(CAST(ano_pregao AS VARCHAR), LPAD(CAST(mes_pregao AS VARCHAR), 2, '0'))"
    relacao = (f"{fonte} WHERE mercado = 'XBSP' AND ativo IN (SELECT ativo_atipico FROM {tabela_cta05}) "
               f"AND {particao} BETWEEN '{baixo:%Y%m}' AND '{alto:%Y%m}' "
               f"AND ({data} BETWEEN DATE '{baixo}' AND DATE '{alto}' OR {data} IS NULL)")
    metricas = [
        _metrica("nulo", "cliente", "cliente IS NULL"),
        _metrica("nulo", "data_pregao", "data_pregao IS NULL"),
        _metrica("tipo_dado", "data_pregao", f"data_pregao IS NOT NULL AND {data} IS NULL"),
        _metrica("dominio", "lado", "lado IS NULL OR lado NOT IN ('Compra', 'Venda')"),
        _metrica("dominio", "tipo_operacao", "tipo_operacao IS NULL OR tipo_operacao NOT IN ('local', 'repasse_enviado', 'repasse_recebido')"),
    ]
    for coluna in ("preco", "quantidade", "volume_negociado"):
        metricas += [_metrica("nulo", coluna, coluna + " IS NULL"),
                     _metrica("tipo_dado", coluna, f"{coluna} IS NOT NULL AND TRY_CAST({coluna} AS DOUBLE) IS NULL"),
                     _metrica("nao_finito", coluna, f"TRY_CAST({coluna} AS DOUBLE) IS NOT NULL AND NOT is_finite(TRY_CAST({coluna} AS DOUBLE))")]
    return {"relation": relacao, "metrics": metricas, "entity": "cliente", "entity_type": "cliente",
            "scope": "Ativos com evento e mercado XBSP, antes de origem/cadastro/vínculos.",
            "duplicate_key": ["cliente", "ativo", "data_pregao", "hora_transacao", "lado", "quantidade", "preco",
                              "volume_negociado", "tipo_operacao", "conta_negociacao", "conta_master", "broker"],
            "duplicate_kind": "repeticao_campos_observados",
            "duplicate_note": "Igualdade dos campos não prova duplicidade indevida; a fonte não tem chave única validada."}


# ----------------------------------------------------------------------------------------------
# Execução das CTAs
# ----------------------------------------------------------------------------------------------
class TradingAhead:
    def __init__(self, cfg, aws, logs):
        self.cfg, self.aws, self.logs = cfg, aws, logs
        self.safra = cfg["SAFRA"]
        self.cache_sql = {}
        self.concluidas, self.esperadas = set(), set()
        self.registros, self.reaproveitadas = [], []
        self.cortes = {}

    # --- SQL -------------------------------------------------------------------------------
    def parametros(self, safra):
        primeiro, ultimo = limites_mes(safra)
        return {"SAFRA": safra, "SAFRA_ANO": safra[:4], "SAFRA_MES": safra[4:],
                "SAFRA_INICIO": primeiro.isoformat(), "SAFRA_FIM": ultimo.isoformat(),
                "DATABASE": self.cfg["DATABASE"], "PREFIXO_TABELA": self.cfg["PREFIXO_TABELA"],
                "S3_CTAS": self.cfg["S3_CTAS"]}

    def montar_sql(self, arquivo, safra, extras=None):
        if arquivo not in self.cache_sql:
            self.cache_sql[arquivo] = self.aws.ler_texto(self.cfg["CHAVE_SQL"] + arquivo)
        valores = dict(self.parametros(safra), **(extras or {}))
        sql = re.sub(r"\{\{\s*(\w+)\s*\}\}", lambda m: str(valores.get(m.group(1), m.group(0))),
                     self.cache_sql[arquivo])
        if "{{" in sql:
            raise ErroExecucao("Parâmetro não substituído em " + arquivo + ": "
                               + ", ".join(sorted(set(re.findall(r"\{\{\s*(\w+)\s*\}\}", sql)))))
        linhas = sql.strip().splitlines()
        while linhas and linhas[0].lstrip().startswith("--"):  # comentário de cabeçalho não vai para o Athena
            linhas.pop(0)
        return "\n".join(linhas).strip().rstrip(";").strip()

    def tabela(self, nome, safra):
        return self.cfg["DATABASE"] + "." + self.cfg["PREFIXO_TABELA"] + nome + "_" + safra

    # --- Athena ----------------------------------------------------------------------------
    def consultar(self, sql, etapa, safra, ler_linhas=False):
        self.logs.etapa_atual = safra + "_" + etapa
        inicio = time.monotonic()
        query_id, estado, estatisticas = None, "NAO_SUBMETIDA", {}
        try:
            query_id = self.aws.athena.start_query_execution(
                QueryString=sql, QueryExecutionContext={"Database": self.cfg["DATABASE"]},
                WorkGroup=self.cfg["WORKGROUP"], ResultConfiguration=self.aws.resultado_athena)["QueryExecutionId"]
            emit("query_submitted", etapa=etapa, safra=safra, query_id=query_id)
            while True:
                execucao = self.aws.athena.get_query_execution(QueryExecutionId=query_id)["QueryExecution"]
                estado = execucao["Status"]["State"]
                estatisticas = execucao.get("Statistics", {})
                if estado in ("SUCCEEDED", "FAILED", "CANCELLED"):
                    break
                if time.monotonic() - inicio > TEMPO_MAXIMO_CONSULTA_S:
                    self.aws.athena.stop_query_execution(QueryExecutionId=query_id)
                    estado = "TIMEOUT"
                    break
                time.sleep(INTERVALO_CONSULTA_S)
            if estado != "SUCCEEDED":
                status = execucao.get("Status", {})
                motivo = status.get("StateChangeReason", "")
                erro_athena = status.get("AthenaError", {})
                self.logs.detalhe("erro_consulta", "consulta", query_id,
                                  {"state": estado, "error_category": erro_athena.get("ErrorCategory"),
                                   "error_type_athena": erro_athena.get("ErrorType"),
                                   "retryable": erro_athena.get("Retryable"), "mensagem": motivo[:1500]},
                                  etapa=etapa, safra=safra, query_id=query_id)
                raise ErroExecucao("Consulta da etapa " + etapa + " (safra " + safra + ") terminou como "
                                   + estado + ": " + motivo[:500])
            linhas = self.ler_resultado(query_id) if ler_linhas else None
            return {"query_id": query_id, "linhas": linhas}
        finally:
            tempo = time.monotonic() - inicio
            lidos = int(estatisticas.get("DataScannedInBytes", 0) or 0)
            falhou = estado != "SUCCEEDED"
            self.logs.resumo("consulta", coluna=etapa, afetados=int(falhou), total=1,
                             acao="GATE" if falhou else "ok", tolerancia=0.0, etapa=etapa, safra=safra,
                             query_id=query_id, tempo=tempo, bytes_lidos=lidos)
            emit("tempo_consulta", etapa=etapa, safra=safra, query_id=query_id, estado=estado,
                 segundos=round(tempo, 3), bytes_lidos=lidos)

    def ler_resultado(self, query_id, maximo=10000):
        linhas, token, nomes = [], None, None
        while True:
            kwargs = {"QueryExecutionId": query_id, "MaxResults": 1000}
            if token:
                kwargs["NextToken"] = token
            resposta = self.aws.athena.get_query_results(**kwargs)
            conjunto = resposta["ResultSet"]
            dados = conjunto.get("Rows", [])
            if nomes is None:  # o Athena manda o cabeçalho só na primeira página
                nomes = [c["Name"] for c in conjunto["ResultSetMetadata"]["ColumnInfo"]]
                dados = dados[1:]
            for linha in dados:
                valores = linha.get("Data", [])
                linhas.append({nome: (valores[i].get("VarCharValue") if i < len(valores) else None)
                               for i, nome in enumerate(nomes)})
            token = resposta.get("NextToken")
            if not token or len(linhas) >= maximo:
                return linhas[:maximo]

    def select(self, sql, etapa, safra):
        return self.consultar(sql, etapa, safra, ler_linhas=True)["linhas"]

    # --- CTAS ------------------------------------------------------------------------------
    def materializar(self, etapa, sql, safra):
        """DROP TABLE + limpeza do destino + CTAS + contagem de linhas, com logs de tempo e volumetria."""
        self.logs.etapa_atual = safra + "_" + etapa
        inicio, erro = time.monotonic(), None
        try:
            achado_tabela = re.search(r"CREATE\s+TABLE\s+([A-Za-z0-9_]+)\.([A-Za-z0-9_]+)", sql, re.I)
            achado_local = re.search(r"external_location\s*=\s*'([^']+)'", sql, re.I)
            if not achado_tabela or not achado_local:
                raise ErroExecucao("A SQL da etapa " + etapa + " precisa começar com CREATE TABLE e ter external_location.")
            banco, nome = achado_tabela.group(1).lower(), achado_tabela.group(2).lower()
            if banco != self.cfg["DATABASE"] or not nome.startswith(self.cfg["PREFIXO_TABELA"]):
                raise ErroExecucao("Tabela fora do padrão " + self.cfg["DATABASE"] + "." + self.cfg["PREFIXO_TABELA"]
                                   + "*: " + banco + "." + nome + ". Confira se a SQL da pasta sql/ é a versão parametrizada.")
            local = achado_local.group(1)
            if not local.endswith("/"):
                raise ErroExecucao("O external_location da etapa " + etapa + " precisa terminar com '/'.")
            tabela = banco + "." + nome
            self.consultar("DROP TABLE IF EXISTS " + tabela, etapa + "_drop", safra)
            apagados = self.aws.limpar_destino(local)
            criada = self.consultar(sql, etapa, safra)
            contagem = self.select("SELECT COUNT(*) AS row_count FROM " + tabela, etapa + "_count", safra)
            linhas = int(contagem[0]["row_count"])
            registro = {"safra": safra, "etapa": etapa, "tabela": tabela, "local": local, "linhas": linhas,
                        "query_id": criada["query_id"], "arquivos_antigos_apagados": apagados}
            self.registros.append(registro)
            self.concluidas.add((safra, etapa))
            self.logs.resumo("volumetria", coluna=tabela, afetados=linhas, total=linhas, etapa=etapa,
                             safra=safra, query_id=criada["query_id"])
            emit("stage_count", **registro)
            return registro
        except Exception as caught:
            erro = caught
            raise
        finally:
            self.logs.resumo("tempo_etapa", afetados=int(erro is not None), total=1,
                             acao="GATE" if erro else "ok", etapa=etapa, safra=safra,
                             tempo=time.monotonic() - inicio)

    def auditar_fonte(self, etapa, safra):
        espec = especificacao_fonte(etapa, safra, self.tabela("CTA5_EstudoVariacao", safra))
        campos = ["COUNT(*) AS total"] + [f"COUNT_IF({m['condition']}) AS n_{i}" for i, m in enumerate(espec["metrics"])]
        dados = self.select("SELECT " + ", ".join(campos) + " FROM " + espec["relation"], etapa + "_qa_summary", safra)[0]
        total = int(dados["total"])
        self.logs.detalhe("escopo_verificacao", "fonte", etapa,
                          {"escopo": espec["scope"], "modo": "OBSERVACIONAL_SEM_FILTRO_ADICIONAL"}, etapa=etapa, safra=safra)
        self.logs.resumo("base_fonte_vazia", afetados=int(total == 0), total=1,
                         acao="AVISO" if total == 0 else "ok", etapa=etapa, safra=safra)
        limite = self.cfg["MAX_DETALHES"]
        for i, metrica in enumerate(espec["metrics"]):
            n = int(dados[f"n_{i}"])
            self.logs.resumo(metrica["kind"], coluna=metrica["column"], afetados=n, total=total,
                             acao="log" if n else "ok", lado="fonte", etapa=etapa, safra=safra)
            if n and limite:
                entidades = self.select(
                    f"SELECT DISTINCT CAST({espec['entity']} AS VARCHAR) AS entidade FROM {espec['relation']} "
                    f"AND ({metrica['condition']}) ORDER BY entidade LIMIT {limite + 1}", etapa + f"_qa_detail_{i}", safra)
                for item in entidades[:limite]:
                    self.logs.detalhe(metrica["kind"], espec["entity_type"], item["entidade"] or "sem_identificador",
                                      {"motivo": metrica["kind"], "coluna": metrica["column"]},
                                      coluna=metrica["column"], etapa=etapa, safra=safra)
                if len(entidades) > limite:
                    self.logs.detalhe("detalhes_limitados", "verificacao", metrica["column"],
                                      {"limite": limite, "contagem_agregada_completa": n}, etapa=etapa, safra=safra)
        chave = ", ".join(espec["duplicate_key"])
        repeticao = self.select(f"WITH grupos AS (SELECT {chave}, COUNT(*) AS n FROM {espec['relation']} GROUP BY {chave}) "
                                "SELECT COALESCE(SUM(n), 0) AS total, COALESCE(SUM(n - 1), 0) AS extras FROM grupos",
                                etapa + "_qa_repetitions", safra)[0]
        self.logs.resumo(espec["duplicate_kind"], coluna="+".join(espec["duplicate_key"]),
                         afetados=int(repeticao["extras"]), total=int(repeticao["total"]),
                         acao="log" if int(repeticao["extras"]) else "ok", etapa=etapa, safra=safra)
        self.logs.detalhe(espec["duplicate_kind"], "fonte", etapa, {"interpretacao": espec["duplicate_note"]},
                          etapa=etapa, safra=safra)

    def projecao_chave(self, alias="t"):
        campos = []
        for nome in CHAVE_ALERTA:
            if nome == "ativo_negociado_4letras":
                campos.append(f"SUBSTR({alias}.ativo_negociado, 1, 4) AS {nome}")
            elif nome == "diferenca_volume":
                campos.append(f"ABS({alias}.soma_volume_venda_15dias - {alias}.soma_volume_compra_15dias) AS {nome}")
            else:
                campos.append(f"{alias}.{nome}")
        return ", ".join(campos)

    def auditar_vinculos(self, safra):
        """Quantas linhas extras os vínculos geram na CTA13 base (a calibração e os alertas deduplicam)."""
        chave = ", ".join(CHAVE_ALERTA)
        linha = self.select(f"WITH base AS (SELECT {self.projecao_chave('t')} FROM {self.tabela(TABELA_BASE_P99, safra)} t), "
                            f"grupos AS (SELECT {chave}, COUNT(*) AS n FROM base GROUP BY {chave}) "
                            "SELECT COALESCE(SUM(n), 0) AS total, COALESCE(SUM(n - 1), 0) AS extras FROM grupos",
                            "cta13_base_qa_fanout", safra)[0]
        self.logs.resumo("duplicata_chave_contagem", coluna="chave_17_campos_sem_vinculos",
                         afetados=int(linha["extras"]), total=int(linha["total"]), acao="log",
                         etapa="cta13_base", safra=safra)
        self.logs.detalhe("duplicata_chave_contagem", "etapa", "cta13_base",
                          {"regra": "Vínculos preservados no detalhamento; calibração e alertas deduplicam a chave oficial."},
                          etapa="cta13_base", safra=safra)

    # --- Fluxo -----------------------------------------------------------------------------
    def cadeia_base(self, safra):
        for etapa in ETAPAS_BASE:
            if safra == self.safra and self.cfg["DIAGNOSTICOS_FONTES"] and etapa in ("cta01", "cta06"):
                self.auditar_fonte(etapa, safra)
            self.materializar(etapa, self.montar_sql(etapa + ".sql", safra), safra)
        if safra == self.safra:
            self.auditar_vinculos(safra)
        self.logs.gravar()

    def calibrar(self, meses):
        baixo, alto = janela_historica(self.safra)
        partes = [f"SELECT {self.projecao_chave('t')}\nFROM {self.tabela(TABELA_BASE_P99, mes)} t\n"
                  f"WHERE CAST(t.data_evento AS DATE) BETWEEN DATE '{baixo}' AND DATE '{alto}'" for mes in meses]
        sql = self.montar_sql("p99_base_calibracao.sql", self.safra, {"UNION_HISTORICO": "\nUNION ALL\n".join(partes)})
        tabela = self.materializar("p99_base_calibracao", sql, self.safra)["tabela"]
        estatisticas = self.select(
            "SELECT tipo_pessoa, COUNT(*) AS total, COUNT(resultado) AS valid_count, "
            "COUNT_IF(resultado IS NOT NULL AND NOT is_finite(CAST(resultado AS DOUBLE))) AS invalid_count, "
            "COUNT_IF(resultado < 0) AS negative_count, COUNT_IF(resultado = 0) AS zero_count "
            "FROM " + tabela + " GROUP BY tipo_pessoa", "p99_population_stats", self.safra)
        por_publico = {linha["tipo_pessoa"]: linha for linha in estatisticas}
        for codigo, linha in por_publico.items():
            publico = {"F": "PF", "J": "PJ"}.get(codigo, "DESCONHECIDO")
            total = int(linha["total"])
            for tipo, chave in (("nulo_resultado", "valid_count"), ("nao_finito", "invalid_count"),
                                ("resultado_negativo", "negative_count"), ("resultado_zero", "zero_count")):
                n = total - int(linha[chave]) if chave == "valid_count" else int(linha[chave])
                self.logs.resumo(tipo, coluna="resultado", afetados=n, total=total,
                                 acao="GATE" if chave == "invalid_count" and n else "log", publico=publico,
                                 etapa="calibracao", tolerancia=0.0 if chave == "invalid_count" else None)
        if set(por_publico) != {"F", "J"}:
            raise ErroExecucao("O histórico de 182 dias precisa ter PF e PJ; encontrado: " + ", ".join(sorted(por_publico)))
        if any(int(por_publico[c]["invalid_count"]) for c in "FJ"):
            raise ErroExecucao("O histórico tem resultado não finito (NaN/infinito).")
        posicoes = {c: posicoes_p99(int(por_publico[c]["valid_count"])) for c in "FJ"}
        filtro = " OR ".join(f"(tipo_pessoa = '{c}' AND rank_number IN ({posicoes[c][0]}, {posicoes[c][1]}))" for c in "FJ")
        ordenados = self.select(
            "WITH ranked AS (SELECT tipo_pessoa, resultado, ROW_NUMBER() OVER (PARTITION BY tipo_pessoa "
            "ORDER BY resultado) AS rank_number FROM " + tabela + " WHERE resultado IS NOT NULL) "
            "SELECT tipo_pessoa, resultado, rank_number FROM ranked WHERE " + filtro, "p99_exact_ranks", self.safra)
        valores = {(r["tipo_pessoa"], int(r["rank_number"])): float(r["resultado"]) for r in ordenados}
        for codigo in "FJ":
            n = int(por_publico[codigo]["valid_count"])
            inferior, superior, peso = posicoes[codigo]
            p99 = interpolar_p99(valores[(codigo, inferior)], valores[(codigo, superior)], n)
            publico = "PF" if codigo == "F" else "PJ"
            corte = {"p99": p99, "cutoff": max(p99, PISO_BRL), "sample_size": n, "lower_rank": inferior,
                     "upper_rank": superior, "weight": peso, "history_start": baixo.isoformat(),
                     "history_end": alto.isoformat(), "history_days": DIAS_HISTORICO, "floor": PISO_BRL}
            self.cortes[publico] = corte
            self.logs.resumo("calibracao_p99", coluna="resultado", total=n, etapa="calibracao", publico=publico)
            self.logs.detalhe("calibracao_p99", "publico", publico, corte, coluna="resultado",
                              etapa="calibracao", publico=publico)
            emit("p99_calibrated", publico=publico, **corte)
        self.logs.gravar()

    def publicar(self, publico):
        corte = self.cortes[publico]
        extras = {"PUBLICO": publico, "TABELA_ORIGEM": ORIGEM_ALERTAS[publico], "P99": repr(corte["p99"]),
                  "CORTE": repr(corte["cutoff"]), "VERSAO_REGRA": POLICY_VERSION, "ID_EXECUCAO": self.cfg["ID_EXECUCAO"]}
        sufixo = publico.lower()
        self.materializar("alertas_" + sufixo + "_vinculos", self.montar_sql("alertas_vinculos.sql", self.safra, extras), self.safra)
        final = self.materializar("alertas_" + sufixo, self.montar_sql("alertas_finais.sql", self.safra, extras), self.safra)
        checagem = self.select(
            "SELECT COUNT_IF(resultado_final <> 'ALERTA' OR resultado_final IS NULL OR resultado IS NULL "
            "OR NOT is_finite(CAST(resultado AS DOUBLE)) OR resultado <= corte_financeiro_aplicado "
            "OR corte_financeiro_aplicado < 100000) AS invalid_count, "
            "COUNT(*) - COUNT(DISTINCT id_alerta) AS duplicate_ids FROM " + final["tabela"],
            "verify_" + sufixo + "_published", self.safra)[0]
        for chave in ("invalid_count", "duplicate_ids"):
            n = int(checagem[chave])
            self.logs.resumo(chave, afetados=n, total=final["linhas"], acao="GATE" if n else "ok",
                             etapa="verify_" + sufixo + "_published", publico=publico, tolerancia=0.0)
        if int(checagem["invalid_count"]) or int(checagem["duplicate_ids"]):
            raise ErroExecucao("Falha na conferência da tabela final de alertas " + publico + ".")
        return final

    def planejar_historico(self):
        """Define quais safras do histórico precisam ser calculadas e quais são reaproveitadas."""
        calcular = []
        for mes in meses_historico(self.safra):
            nome = self.cfg["PREFIXO_TABELA"] + TABELA_BASE_P99 + "_" + mes
            if not self.cfg["RECALCULAR_HISTORICO"] and self.aws.tabela_existe(nome):
                self.reaproveitadas.append(mes)
                self.logs.resumo("reuso_historico", coluna=nome.lower(), afetados=0, total=1,
                                 etapa="cta13_base", safra=mes)
                self.logs.detalhe("reuso_historico", "tabela", self.cfg["DATABASE"] + "." + nome.lower(),
                                  {"motivo": "CTA13 base da safra já existe; --RECALCULAR_HISTORICO true refaz"},
                                  etapa="cta13_base", safra=mes)
            else:
                calcular.append(mes)
        self.esperadas = {(m, e) for m in calcular + [self.safra] for e in ETAPAS_BASE}
        self.esperadas |= {(self.safra, e) for e in ["p99_base_calibracao"] + ETAPAS_FINAIS + ETAPAS_ALERTAS}
        return calcular

    def executar(self):
        calcular = self.planejar_historico()
        emit("plano_historico", calcular=calcular, reaproveitar=self.reaproveitadas)
        for mes in calcular:
            self.cadeia_base(mes)
        self.cadeia_base(self.safra)
        self.calibrar(meses_historico(self.safra))
        for etapa in ETAPAS_FINAIS:
            self.materializar(etapa, self.montar_sql(etapa + ".sql", self.safra), self.safra)
        finais = {publico: self.publicar(publico) for publico in ("PF", "PJ")}
        faltando = sorted(self.esperadas - self.concluidas)
        self.logs.resumo("cobertura_etapas", afetados=len(faltando), total=len(self.esperadas),
                         acao="GATE" if faltando else "ok", etapa="conclusao", tolerancia=0.0)
        if faltando:
            raise ErroExecucao("Etapas planejadas não concluídas: " + ", ".join(m + "_" + e for m, e in faltando))
        return {"alertas_pf": finais["PF"]["linhas"], "tabela_alertas_pf": finais["PF"]["tabela"],
                "alertas_pj": finais["PJ"]["linhas"], "tabela_alertas_pj": finais["PJ"]["tabela"],
                "cortes": self.cortes, "safras_calculadas": calcular, "safras_reaproveitadas": self.reaproveitadas}

    def plano(self):
        """Modo plano: monta todas as SQLs e grava em temp/plano/ sem rodar nada no Athena."""
        calcular = self.planejar_historico()
        destino = self.cfg["S3_TEMP"] + "plano/" + self.cfg["ID_EXECUCAO"] + "/"
        lista = []
        def guardar(safra, etapa, sql):
            nome = f"{len(lista) + 1:03d}_{safra}_{etapa}.sql"
            self.aws.gravar_texto(destino + nome, sql + "\n")
            lista.append(nome)
        for mes in calcular + [self.safra]:
            for etapa in ETAPAS_BASE:
                guardar(mes, etapa, self.montar_sql(etapa + ".sql", mes))
        baixo, alto = janela_historica(self.safra)
        partes = [f"SELECT {self.projecao_chave('t')}\nFROM {self.tabela(TABELA_BASE_P99, m)} t\n"
                  f"WHERE CAST(t.data_evento AS DATE) BETWEEN DATE '{baixo}' AND DATE '{alto}'"
                  for m in meses_historico(self.safra)]
        guardar(self.safra, "p99_base_calibracao",
                self.montar_sql("p99_base_calibracao.sql", self.safra, {"UNION_HISTORICO": "\nUNION ALL\n".join(partes)}))
        for etapa in ETAPAS_FINAIS:
            guardar(self.safra, etapa, self.montar_sql(etapa + ".sql", self.safra))
        for publico in ("PF", "PJ"):
            extras = {"PUBLICO": publico, "TABELA_ORIGEM": ORIGEM_ALERTAS[publico], "P99": "100000.0",
                      "CORTE": "100000.0", "VERSAO_REGRA": POLICY_VERSION, "ID_EXECUCAO": self.cfg["ID_EXECUCAO"]}
            guardar(self.safra, "alertas_" + publico.lower() + "_vinculos", self.montar_sql("alertas_vinculos.sql", self.safra, extras))
            guardar(self.safra, "alertas_" + publico.lower(), self.montar_sql("alertas_finais.sql", self.safra, extras))
        self.logs.resumo("plano_gerado", coluna=destino, afetados=len(lista), total=len(lista), etapa="plano", acao="PLANO")
        self.logs.detalhe("plano_gerado", "pasta", destino,
                          {"arquivos": len(lista), "safras_calcular": calcular, "safras_reaproveitar": self.reaproveitadas,
                           "obs": "No plano, P99 e corte aparecem como 100000.0; na execução entram os valores calculados."},
                          etapa="plano")
        return {"pasta_plano": destino, "arquivos": len(lista), "safras_calculadas": calcular,
                "safras_reaproveitadas": self.reaproveitadas}


# ----------------------------------------------------------------------------------------------
# Entrada
# ----------------------------------------------------------------------------------------------
def inventario():
    pacotes = {}
    for nome in ("awswrangler", "boto3", "botocore", "pandas", "numpy", "pyarrow"):
        try:
            pacotes[nome] = importlib.metadata.version(nome)
        except importlib.metadata.PackageNotFoundError:
            pacotes[nome] = "nao_instalado"
    return {"python": platform.python_version(), "pacotes": pacotes}


def main(argv=None):
    argv = sys.argv if argv is None else argv
    inicio = time.monotonic()
    try:
        cfg = configurar(argv)
    except Exception as erro:
        emit("job_failed", etapa="parametros", **descrever_erro(erro))
        raise
    emit("job_started", id_execucao=cfg["ID_EXECUCAO"], safra=cfg["SAFRA"], ambiente=cfg["AMBIENTE"],
         modo=cfg["MODO"], safra_automatica=cfg["SAFRA_AUTOMATICA"], glue_job=cfg["JOB_NAME"],
         glue_run=cfg["ID_TENTATIVA"])
    aws = Aws(cfg)
    logs = LogBook(cfg, aws)
    job = TradingAhead(cfg, aws, logs)
    resultado = {"id_execucao": cfg["ID_EXECUCAO"], "safra": cfg["SAFRA"], "ambiente": cfg["AMBIENTE"],
                 "modo": cfg["MODO"], "regra": POLICY_VERSION, "glue_job": cfg["JOB_NAME"],
                 "glue_run": cfg["ID_TENTATIVA"], "inicio_utc": datetime.now(timezone.utc).isoformat()}
    try:
        logs.resumo("inicio_execucao", total=1, etapa="inicializacao")
        logs.detalhe("inicio_execucao", "execucao", cfg["ID_EXECUCAO"],
                     {"regra": POLICY_VERSION, "observabilidade": OBSERVABILITY_VERSION, "modo": cfg["MODO"],
                      "safra_automatica": cfg["SAFRA_AUTOMATICA"], "glue_job_name": cfg["JOB_NAME"],
                      "glue_job_run_id": cfg["ID_TENTATIVA"], "destino_ctas": cfg["S3_CTAS"],
                      "recalcular_historico": cfg["RECALCULAR_HISTORICO"]}, etapa="inicializacao")
        ambiente = inventario()
        print("=== REQUIREMENTS BEGIN ===", flush=True)
        print(json.dumps(ambiente, ensure_ascii=False, sort_keys=True), flush=True)
        print("=== REQUIREMENTS END ===", flush=True)
        logs.detalhe("ambiente_execucao", "runtime", "python", ambiente, etapa="inicializacao")
        logs.detalhe("ambiente_execucao", "workgroup", cfg["WORKGROUP"], aws.checar_workgroup(), etapa="inicializacao")
        logs.gravar()  # primeira gravação logo no início: falta de permissão aparece em segundos
        resultado.update(job.plano() if cfg["MODO"] == "plano" else job.executar())
        logs.resumo("status_execucao", total=1, acao="OK" if cfg["MODO"] == "executar" else "PLANO", etapa="conclusao")
        logs.detalhe("status_execucao", "execucao", cfg["ID_EXECUCAO"],
                     {"status": "SUCESSO", "modo": cfg["MODO"], "alertas_pf": resultado.get("alertas_pf"),
                      "alertas_pj": resultado.get("alertas_pj")}, etapa="conclusao")
        logs.gravar()
        resultado["status"] = "SUCESSO"
        return resultado
    except Exception as erro:
        etapa = logs.etapa_atual
        resultado.update(status="FALHA", etapa_falha=etapa, erro=descrever_erro(erro))
        logs.resumo("erro_processamento", afetados=1, total=1, acao="GATE", tolerancia=0.0, etapa=etapa)
        logs.detalhe("erro_processamento", "etapa", etapa, descrever_erro(erro), etapa=etapa)
        faltando = sorted(job.esperadas - job.concluidas)
        logs.resumo("etapa_nao_concluida", afetados=len(faltando), total=len(job.esperadas), acao="GATE",
                    etapa="conclusao", tolerancia=0.0)
        logs.detalhe("etapa_nao_concluida", "execucao", cfg["ID_EXECUCAO"],
                      {"etapas": [m + "_" + e for m, e in faltando]}, etapa="conclusao")
        logs.resumo("status_execucao", afetados=1, total=1, acao="GATE", etapa="conclusao", tolerancia=0.0)
        try:
            logs.gravar()
        except Exception as erro_log:
            emit("falha_gravacao_logs_na_saida", **descrever_erro(erro_log))
        emit("job_failed", etapa=etapa, id_execucao=cfg["ID_EXECUCAO"], **descrever_erro(erro))
        raise
    finally:
        resultado["tempo_total_s"] = round(time.monotonic() - inicio, 1)
        resultado["tabelas"] = job.registros
        try:
            aws.gravar_texto(cfg["S3_LOGS"] + "execucoes/" + cfg["ID_EXECUCAO"] + ".json",
                             json.dumps(resultado, ensure_ascii=False, indent=2, default=str),
                             "application/json; charset=utf-8")
        except Exception as erro_json:
            emit("falha_gravacao_resumo_execucao", **descrever_erro(erro_json))
        emit("tempo_execucao_total", id_execucao=cfg["ID_EXECUCAO"], status=resultado.get("status"),
             segundos=resultado["tempo_total_s"])


if __name__ == "__main__":
    main()
