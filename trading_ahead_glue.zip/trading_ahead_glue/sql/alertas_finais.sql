-- Tabela final de alertas: um registro por alerta (o representante dos vínculos).
CREATE TABLE {{DATABASE}}.{{PREFIXO_TABELA}}Alertas_TradingAhead_{{PUBLICO}}_{{SAFRA}}
WITH (
    format = 'PARQUET',
    external_location = '{{S3_CTAS}}Alertas_TradingAhead_{{PUBLICO}}_{{SAFRA}}/'
) AS
SELECT *
FROM {{DATABASE}}.{{PREFIXO_TABELA}}Alertas_TradingAhead_{{PUBLICO}}_Vinculos_{{SAFRA}}
WHERE ordem_vinculo = 1
