-- Corte financeiro final: resultado_final = 'ALERTA' e resultado > max(P99 do público, R$ 100 mil).
-- Mantém todas as linhas de vínculo. ordem_vinculo = 1 marca o representante de cada alerta,
-- qtd_vinculos conta as linhas da mesma chave e id_alerta identifica a chave de 17 campos.
CREATE TABLE {{DATABASE}}.{{PREFIXO_TABELA}}Alertas_TradingAhead_{{PUBLICO}}_Vinculos_{{SAFRA}}
WITH (
    format = 'PARQUET',
    external_location = '{{S3_CTAS}}Alertas_TradingAhead_{{PUBLICO}}_Vinculos_{{SAFRA}}/'
) AS
WITH filtrado AS (
    SELECT
        t.*,
        SUBSTR(t.ativo_negociado, 1, 4) AS ativo_negociado_4letras,
        ABS(t.soma_volume_venda_15dias - t.soma_volume_compra_15dias) AS diferenca_volume,
        CAST('{{P99}}' AS DOUBLE) AS p99_financeiro,
        CAST('{{CORTE}}' AS DOUBLE) AS corte_financeiro_aplicado,
        182 AS dias_historico_percentil,
        '{{VERSAO_REGRA}}' AS versao_regra,
        '{{ID_EXECUCAO}}' AS id_execucao
    FROM {{DATABASE}}.{{PREFIXO_TABELA}}{{TABELA_ORIGEM}}_{{SAFRA}} t
    WHERE t.resultado_final = 'ALERTA'
      AND t.resultado > CAST('{{CORTE}}' AS DOUBLE)
)
SELECT
    f.*,
    TO_HEX(SHA256(TO_UTF8(JSON_FORMAT(CAST(ARRAY[
        CAST(f.codigo_cliente AS VARCHAR), CAST(f.cpf_cnpj_cliente AS VARCHAR), CAST(f.ativo_negociado AS VARCHAR),
        CAST(f.ativo_negociado_4letras AS VARCHAR), CAST(f.tipo_pessoa AS VARCHAR), CAST(f.origem_operacao AS VARCHAR),
        CAST(f.data_evento AS VARCHAR), CAST(f.soma_quantidade_compra_historica AS VARCHAR),
        CAST(f.soma_quantidade_venda_historica AS VARCHAR), CAST(f.soma_quantidade_compra_15dias AS VARCHAR),
        CAST(f.soma_quantidade_venda_15dias AS VARCHAR), CAST(f.quantidade_compra_d0 AS VARCHAR),
        CAST(f.quantidade_venda_d0 AS VARCHAR), CAST(f.soma_quantidade_compra_5diasdepois AS VARCHAR),
        CAST(f.soma_quantidade_venda_5diasdepois AS VARCHAR), CAST(f.resultado AS VARCHAR),
        CAST(f.diferenca_volume AS VARCHAR)
    ] AS JSON))))) AS id_alerta,
    ROW_NUMBER() OVER (
        PARTITION BY f.codigo_cliente, f.cpf_cnpj_cliente, f.ativo_negociado, f.ativo_negociado_4letras,
                     f.tipo_pessoa, f.origem_operacao, f.data_evento, f.soma_quantidade_compra_historica,
                     f.soma_quantidade_venda_historica, f.soma_quantidade_compra_15dias,
                     f.soma_quantidade_venda_15dias, f.quantidade_compra_d0, f.quantidade_venda_d0,
                     f.soma_quantidade_compra_5diasdepois, f.soma_quantidade_venda_5diasdepois,
                     f.resultado, f.diferenca_volume
        ORDER BY f.cnpj_empresa_vinculada, f.ticker_empresa_vinculada, f.pessoa_relacionada, f.linha_negocio
    ) AS ordem_vinculo,
    COUNT(*) OVER (
        PARTITION BY f.codigo_cliente, f.cpf_cnpj_cliente, f.ativo_negociado, f.ativo_negociado_4letras,
                     f.tipo_pessoa, f.origem_operacao, f.data_evento, f.soma_quantidade_compra_historica,
                     f.soma_quantidade_venda_historica, f.soma_quantidade_compra_15dias,
                     f.soma_quantidade_venda_15dias, f.quantidade_compra_d0, f.quantidade_venda_d0,
                     f.soma_quantidade_compra_5diasdepois, f.soma_quantidade_venda_5diasdepois,
                     f.resultado, f.diferenca_volume
    ) AS qtd_vinculos
FROM filtrado f
