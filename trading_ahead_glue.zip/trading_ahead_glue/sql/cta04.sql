CREATE TABLE {{DATABASE}}.{{PREFIXO_TABELA}}CTA4_PrecosEventos_{{SAFRA}}
WITH (
    format = 'PARQUET',
    external_location = '{{S3_CTAS}}CTA4_PrecosEventos_{{SAFRA}}/',
    partitioned_by = ARRAY['SAFRA']
) AS

SELECT 
    a.ativo_atipico,
    CAST(a.data_evento AS DATE) AS data_evento,
    CAST(b.data_fechamento AS DATE) AS data_fechamento,
    b.ativo,
    b.preco_fechamento,
    b.valor_fechamento,
    b.ativo_4letras,
    a.safra
FROM {{DATABASE}}.{{PREFIXO_TABELA}}CTA3_EventosAtipicos_{{SAFRA}} a
INNER JOIN {{DATABASE}}.{{PREFIXO_TABELA}}CTA1_Precos_{{SAFRA}} b
ON a.ativo_atipico = b.ativo
