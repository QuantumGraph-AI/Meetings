-- Separa a CTA13 base (sem corte financeiro) por público. O corte P99/R$ 100 mil é aplicado só no fim.
CREATE TABLE {{DATABASE}}.{{PREFIXO_TABELA}}CTA13_CalculoResultado_PJ_{{SAFRA}}
WITH (
    format = 'PARQUET',
    external_location = '{{S3_CTAS}}CTA13_CalculoResultado_PJ_{{SAFRA}}/',
    partitioned_by = ARRAY['SAFRA']
) AS
SELECT *
FROM {{DATABASE}}.{{PREFIXO_TABELA}}CTA13_CalculoResultado_Base_Estudo_{{SAFRA}}
WHERE tipo_pessoa = 'J'
