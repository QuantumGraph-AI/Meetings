CREATE TABLE {{DATABASE}}.{{PREFIXO_TABELA}}CTA15_CustodiaAtipicos_{{SAFRA}}
WITH (format = 'PARQUET',
      external_location = '{{S3_CTAS}}CTA15_CustodiaAtipicos_{{SAFRA}}/',
      partitioned_by = ARRAY['SAFRA']) AS
SELECT 
  cust.data_referencia,
  cust.codigo_conta,
  cust.ativo,
  -- cust.ativo_4letras,
  cust.quantidade_d0,
  cust.quantidade_d0_shifted,
  -- fr.cnpj_companhia,
  -- fr.nome_empresarial,
  ev.ativo_atipico,
  ev.data_evento,
  '{{SAFRA}}' AS SAFRA
FROM {{DATABASE}}.{{PREFIXO_TABELA}}CTA14_Custodia_{{SAFRA}} cust
INNER JOIN {{DATABASE}}.{{PREFIXO_TABELA}}CTA3_EventosAtipicos_{{SAFRA}} ev
  ON cust.ativo = ev.ativo_atipico
