CREATE TABLE {{DATABASE}}.{{PREFIXO_TABELA}}CTA18_AlertasTradingAhead_PF_{{SAFRA}}
WITH (format = 'PARQUET',
      external_location = '{{S3_CTAS}}CTA18_AlertasTradingAhead_PF_{{SAFRA}}/',
      partitioned_by = ARRAY['SAFRA']) AS
SELECT *
FROM {{DATABASE}}.{{PREFIXO_TABELA}}CTA18_CustodiaReversao_{{SAFRA}}
WHERE resultado_final = 'ALERTA'
