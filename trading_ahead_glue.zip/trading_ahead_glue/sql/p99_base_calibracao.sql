-- Base do P99: CTA13 base das safras dos 182 dias anteriores, sem corte financeiro,
-- filtrada pela data do evento e deduplicada pela chave de 17 campos (tira a repetição dos vínculos).
-- O bloco UNION_HISTORICO abaixo é montado pelo orquestrador, com um SELECT por safra do histórico.
CREATE TABLE {{DATABASE}}.{{PREFIXO_TABELA}}P99_BaseCalibracao_{{SAFRA}}
WITH (
    format = 'PARQUET',
    external_location = '{{S3_CTAS}}P99_BaseCalibracao_{{SAFRA}}/'
) AS
SELECT DISTINCT *
FROM (
{{UNION_HISTORICO}}
) historico
