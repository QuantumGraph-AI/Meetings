# Testes usados na validação

Rodaram num Linux com:

- Trino 477 (Java 24) com catálogo Hive local (`hive.metastore=file`, `fs.native-local.enabled=true`,
  `hive.non-managed-table-writes-enabled=true`) e `query.max-stage-count=1000` (a CTA6 gera 311 estágios).
- Python 3.9 com as versões do Glue Python Shell: boto3 1.21.21, botocore 1.24.21, awswrangler 2.15.1,
  pandas 1.4.2, numpy 1.22.3, pyarrow 7.0.0, mais `trino` e `moto[s3,glue]==4.2.14` só para teste.

Ordem:

1. `python gerar_dados.py` cria as fontes simuladas no Trino.
2. `python rodar_teste.py` roda o orquestrador de ponta a ponta (plano, execução 202509, reexecução, falha
   simulada, role sem permissão de apagar e workgroup forçado) e confere P99, alertas, cenários e logs (51 verificações).
3. `python teste_logs_awswrangler.py` grava os logs com o awswrangler real sobre S3/Glue simulados.
4. `python consultas_monitoramento.py` roda as consultas de monitoramento do guia sobre os logs do teste.

`evidencia_bloqueios_codigo_original.py` mostra, sem AWS, os parâmetros que o botocore do Glue recusa no
código original. `converter_sql_e_provar_paridade.py` gerou a pasta `sql/` e prova que só banco, prefixo e
caminho mudaram. Os caminhos `/home/claude/...` são do ambiente de teste; ajuste se for rodar em outro lugar.
