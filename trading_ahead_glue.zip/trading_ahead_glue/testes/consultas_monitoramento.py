"""Registra as pastas de log do teste como tabelas e roda as consultas de monitoramento que vão no guia."""
import sys
sys.path.insert(0, "/home/claude/work/teste")
from fake_aws import conexao_trino

def q(sql, mostrar=True):
    con = conexao_trino("workspace_db"); cur = con.cursor(); cur.execute(sql)
    linhas = cur.fetchall(); cols = [d[0] for d in (cur.description or [])]; con.close()
    if mostrar:
        print("\n> " + sql.strip().splitlines()[0][:110])
        for l in linhas[:12]:
            print("  ", dict(zip(cols, l)))
    return linhas

base = "local:///s3/itau-self-wkp-sa-east-1-886436964833/TRADING_AHEAD/logs/hml"
cols_res = ("data_execucao timestamp(3), tipo_verificacao varchar, coluna varchar, lado_avaliado varchar, n_afetados bigint, "
            "total_avaliado bigint, pct double, tolerancia_pct double, acao varchar")
cols_det = ("data_execucao timestamp(3), tipo_verificacao varchar, coluna varchar, entidade_tipo varchar, entidade_id varchar, "
            "detalhe varchar")
extra = ("id_execucao varchar, id_tentativa varchar, etapa varchar, publico varchar, query_id varchar, "
         "tempo_total_s double, bytes_lidos bigint, safra varchar")
for tipo, cols in (("resumo", cols_res), ("detalhe", cols_det)):
    q(f"DROP TABLE IF EXISTS hive.workspace_db.trading_ahead_hml_log_{tipo}", False)
    q(f"CREATE TABLE hive.workspace_db.trading_ahead_hml_log_{tipo} ({cols}, {extra}) WITH (format='PARQUET', "
      f"external_location='{base}/log_{tipo}', partitioned_by=ARRAY['safra'])", False)
    q(f"CALL hive.system.sync_partition_metadata('workspace_db', 'trading_ahead_hml_log_{tipo}', 'FULL')", False)

# 1) Últimas execuções e status
q("""SELECT id_execucao, acao, MAX(data_execucao) AS quando
FROM workspace_db.trading_ahead_hml_log_resumo
WHERE tipo_verificacao = 'status_execucao'
GROUP BY id_execucao, acao ORDER BY quando DESC LIMIT 10""")
# 2) Onde e por que falhou
q("""SELECT data_execucao, etapa, tipo_verificacao, detalhe
FROM workspace_db.trading_ahead_hml_log_detalhe
WHERE tipo_verificacao IN ('erro_processamento', 'erro_consulta', 'etapa_nao_concluida')
ORDER BY data_execucao DESC LIMIT 10""")
# 3) Tabelas escritas, linhas e tempo por etapa de uma execução
ultima = q("""SELECT id_execucao FROM workspace_db.trading_ahead_hml_log_resumo
WHERE tipo_verificacao = 'status_execucao' AND acao = 'OK' ORDER BY data_execucao DESC LIMIT 1""", False)[0][0]
q(f"""SELECT safra, etapa, coluna AS tabela, n_afetados AS linhas
FROM workspace_db.trading_ahead_hml_log_resumo
WHERE id_execucao = '{ultima}' AND tipo_verificacao = 'volumetria'
ORDER BY data_execucao""")
q(f"""SELECT etapa, ROUND(SUM(tempo_total_s), 1) AS segundos, ROUND(SUM(bytes_lidos) / 1e9, 3) AS gb_lidos, COUNT(*) AS consultas
FROM workspace_db.trading_ahead_hml_log_resumo
WHERE id_execucao = '{ultima}' AND tipo_verificacao = 'consulta'
GROUP BY etapa ORDER BY segundos DESC LIMIT 10""")
# 4) Cortes do P99
q("""SELECT safra, publico, json_extract_scalar(detalhe, '$.p99') AS p99, json_extract_scalar(detalhe, '$.cutoff') AS corte,
       json_extract_scalar(detalhe, '$.sample_size') AS amostra, id_execucao
FROM workspace_db.trading_ahead_hml_log_detalhe
WHERE tipo_verificacao = 'calibracao_p99' ORDER BY data_execucao DESC LIMIT 4""")
# 5) Qualidade das fontes (diagnósticos)
q(f"""SELECT etapa, tipo_verificacao, coluna, n_afetados, total_avaliado, pct
FROM workspace_db.trading_ahead_hml_log_resumo
WHERE id_execucao = '{ultima}' AND lado_avaliado = 'fonte' AND n_afetados > 0""")
# 6) Alertas finais da safra
q("""SELECT codigo_cliente, ativo_negociado, data_evento, ROUND(resultado, 2) AS resultado, corte_financeiro_aplicado, qtd_vinculos
FROM workspace_db.hml_alertas_tradingahead_pf_202509 ORDER BY resultado DESC""")
