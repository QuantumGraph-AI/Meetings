"""Troca somente database/tabela/caminho das SQLs originais por parâmetros e prova que nada mais mudou."""
import pathlib, sys
origem = pathlib.Path(sys.argv[1]); destino = pathlib.Path(sys.argv[2])
S3_ANTIGO = "s3://itau-self-wkp-sa-east-1-886436964833/TRADING_AHEAD/ctas/"
for f in sorted(origem.glob("*.sql")):
    original = f.read_text(encoding="utf-8")
    novo = original.replace("workspace_db.CTA", "{{DATABASE}}.{{PREFIXO_TABELA}}CTA").replace(S3_ANTIGO, "{{S3_CTAS}}")
    # Prova: desfazendo a troca volta exatamente ao arquivo original (corpo da lógica intacto).
    volta = novo.replace("{{DATABASE}}.{{PREFIXO_TABELA}}CTA", "workspace_db.CTA").replace("{{S3_CTAS}}", S3_ANTIGO)
    assert volta == original, f.name
    assert "workspace_db" not in novo and "TRADING_AHEAD" not in novo, f.name
    (destino / f.name).write_text(novo.lstrip("\n"), encoding="utf-8")
    print(f"{f.name:24s} ok  trocas_db={original.count('workspace_db.CTA'):2d} trocas_s3={original.count(S3_ANTIGO)}")
