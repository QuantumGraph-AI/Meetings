"""Prova offline (sem AWS) dos bloqueios do código original no Glue Python Shell 3.9 (botocore 1.24.21)."""
import sys, subprocess, json, importlib.metadata as md
import boto3, botocore
from botocore.exceptions import ParamValidationError
print("boto3", boto3.__version__, "| botocore", botocore.__version__, "| python", sys.version.split()[0])
s = boto3.session.Session(aws_access_key_id="x", aws_secret_access_key="y", region_name="sa-east-1")
s3 = s.client("s3"); athena = s.client("athena")
def tenta(nome, fn):
    try:
        fn(); print(f"[{nome}] passou na validação")
    except ParamValidationError as e:
        print(f"[{nome}] FALHA: {str(e).splitlines()[0]}")
    except Exception as e:
        print(f"[{nome}] outro erro (validação passou): {type(e).__name__}")
tenta("S3 put_object IfNoneMatch (claim.json/recibos)", lambda: s3.put_object(Bucket="b", Key="k", Body=b"x", IfNoneMatch="*"))
tenta("Athena ResultReuseConfiguration (todas as consultas)", lambda: athena.start_query_execution(
    QueryString="SELECT 1", WorkGroup="w", ResultReuseConfiguration={"ResultReuseByAgeConfiguration": {"Enabled": False}}))
tenta("Athena ResultConfiguration.ExpectedBucketOwner", lambda: athena.start_query_execution(
    QueryString="SELECT 1", WorkGroup="w", ResultConfiguration={"OutputLocation": "s3://b/p/", "ExpectedBucketOwner": "886436964833"}))
