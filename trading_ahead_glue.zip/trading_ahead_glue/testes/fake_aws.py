"""AWS falsa para teste local: Athena executa no Trino (motor do Athena v3), S3 é uma pasta local,
Glue responde get_table pelo catálogo do Trino. Toda chamada passa pela validação de parâmetros do
botocore instalado (1.24.21, o mesmo do Glue Python Shell 3.9), então parâmetro inexistente quebra aqui também."""
import io
import os
import time
import uuid
from datetime import date, datetime, timezone
from decimal import Decimal

import boto3
import trino
from botocore.exceptions import ClientError, ParamValidationError
from botocore.validate import ParamValidator

RAIZ = "/home/claude/sim/root"          # local.location do Trino
RAIZ_S3 = RAIZ + "/s3"                  # s3://bucket/chave  ->  RAIZ_S3/bucket/chave
_modelos = boto3.session.Session(aws_access_key_id="x", aws_secret_access_key="y", region_name="sa-east-1")
_clientes_modelo = {n: _modelos.client(n) for n in ("athena", "s3", "glue")}


def validar(servico, operacao, params):
    modelo = _clientes_modelo[servico].meta.service_model.operation_model(operacao)
    relatorio = ParamValidator().validate(params, modelo.input_shape)
    if relatorio.has_errors():
        raise ParamValidationError(report=relatorio.generate_report())


def erro(codigo, mensagem, operacao):
    return ClientError({"Error": {"Code": codigo, "Message": mensagem}}, operacao)


def conexao_trino(schema="default"):
    return trino.dbapi.connect(host="localhost", port=8085, user="teste", catalog="hive", schema=schema)


def para_texto(valor):
    if valor is None:
        return None
    if isinstance(valor, bool):
        return "true" if valor else "false"
    if isinstance(valor, (date, datetime)):
        return valor.isoformat(sep=" ") if isinstance(valor, datetime) else valor.isoformat()
    if isinstance(valor, float):
        return repr(valor)
    if isinstance(valor, Decimal):
        return format(valor, "f")
    return str(valor)


class FakeAthena:
    def __init__(self, workgroup_forca=False, falhar_etapa_contendo=None):
        self.execucoes = {}
        self.consultas = []
        self.workgroup_forca = workgroup_forca
        self.falhar_contendo = falhar_etapa_contendo

    def get_work_group(self, **kw):
        validar("athena", "GetWorkGroup", kw)
        return {"WorkGroup": {"Name": kw["WorkGroup"], "State": "ENABLED", "Configuration": {
            "EnforceWorkGroupConfiguration": self.workgroup_forca,
            "EngineVersion": {"SelectedEngineVersion": "AUTO", "EffectiveEngineVersion": "Athena engine version 3"},
            "ResultConfiguration": {"OutputLocation": "s3://bucket-workgroup/resultados/",
                                    "EncryptionConfiguration": {"EncryptionOption": "SSE_S3"}}}}}

    def start_query_execution(self, **kw):
        validar("athena", "StartQueryExecution", kw)
        sql = kw["QueryString"]
        qid = str(uuid.uuid4())
        self.consultas.append(sql)
        registro = {"sql": sql, "estado": "SUCCEEDED", "motivo": None, "colunas": [], "linhas": [], "bytes": 0,
                    "chamadas": 0, "saida": kw.get("ResultConfiguration", {}).get("OutputLocation"),
                    "workgroup": kw.get("WorkGroup")}
        traduzida = sql.replace("s3://", "local:///s3/")
        try:
            if self.falhar_contendo and self.falhar_contendo in sql:
                raise trino.exceptions.TrinoUserError({"message": "Simulação de falha", "errorName": "GENERIC_USER_ERROR",
                                                       "errorType": "USER_ERROR", "errorCode": 1})
            if self.workgroup_forca and "external_location" in sql:
                raise trino.exceptions.TrinoUserError({"message": "Please remove the 'external_location' property and resubmit the query.",
                                                       "errorName": "INVALID_TABLE_PROPERTY", "errorType": "USER_ERROR", "errorCode": 2})
            con = conexao_trino(kw.get("QueryExecutionContext", {}).get("Database", "default"))
            cur = con.cursor()
            cur.execute(traduzida)
            linhas = cur.fetchall()
            registro["colunas"] = [d[0] for d in (cur.description or [])]
            registro["linhas"] = [[para_texto(v) for v in linha] for linha in linhas]
            registro["bytes"] = int((cur.stats or {}).get("processedBytes", 0) or 0)
            con.close()
        except trino.exceptions.TrinoUserError as e:
            registro.update(estado="FAILED", motivo=f"{e.error_name}: {e.message}")
        self.execucoes[qid] = registro
        return {"QueryExecutionId": qid}

    def get_query_execution(self, **kw):
        validar("athena", "GetQueryExecution", kw)
        r = self.execucoes[kw["QueryExecutionId"]]
        r["chamadas"] += 1
        estado = "RUNNING" if r["chamadas"] == 1 else r["estado"]  # força o laço de espera a rodar
        status = {"State": estado, "SubmissionDateTime": datetime.now(timezone.utc)}
        if estado == "FAILED":
            status["StateChangeReason"] = r["motivo"]
            status["AthenaError"] = {"ErrorCategory": 2, "ErrorType": 1306, "Retryable": False, "ErrorMessage": r["motivo"]}
        return {"QueryExecution": {"QueryExecutionId": kw["QueryExecutionId"], "Query": r["sql"], "Status": status,
                                   "WorkGroup": r["workgroup"], "ResultConfiguration": {"OutputLocation": r["saida"]},
                                   "Statistics": {"DataScannedInBytes": r["bytes"], "EngineExecutionTimeInMillis": 5}}}

    def get_query_results(self, **kw):
        validar("athena", "GetQueryResults", kw)
        r = self.execucoes[kw["QueryExecutionId"]]
        inicio = int(kw.get("NextToken") or 0)
        tamanho = kw.get("MaxResults", 1000)
        cabecalho = [{"Data": [{"VarCharValue": c} for c in r["colunas"]]}] if inicio == 0 else []
        pedaco = r["linhas"][inicio:inicio + tamanho - len(cabecalho)]
        dados = [{"Data": [({"VarCharValue": v} if v is not None else {}) for v in linha]} for linha in pedaco]
        fim = inicio + len(pedaco)
        resposta = {"ResultSet": {"Rows": cabecalho + dados,
                                  "ResultSetMetadata": {"ColumnInfo": [{"Name": c, "Type": "varchar"} for c in r["colunas"]]}}}
        if fim < len(r["linhas"]):
            resposta["NextToken"] = str(fim)
        return resposta

    def stop_query_execution(self, **kw):
        validar("athena", "StopQueryExecution", kw)
        return {}


class _Corpo(io.BytesIO):
    pass


class FakeS3:
    TAMANHO_PAGINA = 3  # pequeno de propósito, para exercitar a paginação

    def _caminho(self, bucket, chave):
        return os.path.join(RAIZ_S3, bucket, chave)

    def get_object(self, **kw):
        validar("s3", "GetObject", kw)
        caminho = self._caminho(kw["Bucket"], kw["Key"])
        if not os.path.isfile(caminho):
            raise erro("NoSuchKey", "The specified key does not exist.", "GetObject")
        with open(caminho, "rb") as f:
            return {"Body": _Corpo(f.read())}

    def put_object(self, **kw):
        validar("s3", "PutObject", kw)
        caminho = self._caminho(kw["Bucket"], kw["Key"])
        os.makedirs(os.path.dirname(caminho), exist_ok=True)
        corpo = kw["Body"]
        with open(caminho, "wb") as f:
            f.write(corpo if isinstance(corpo, bytes) else corpo.read())
        return {"ETag": "x"}

    def list_objects_v2(self, **kw):
        validar("s3", "ListObjectsV2", kw)
        base = os.path.join(RAIZ_S3, kw["Bucket"])
        chaves = []
        for raiz, _, arquivos in os.walk(base):
            for a in arquivos:
                chave = os.path.relpath(os.path.join(raiz, a), base)
                if chave.startswith(kw.get("Prefix", "")):
                    chaves.append(chave)
        chaves.sort()
        depois_de = kw.get("ContinuationToken") or kw.get("StartAfter") or ""
        restantes = [c for c in chaves if c > depois_de]  # como no S3: continua depois da última chave vista
        pagina = restantes[:self.TAMANHO_PAGINA]
        resposta = {"Contents": [{"Key": c} for c in pagina], "IsTruncated": len(restantes) > len(pagina)}
        if resposta["IsTruncated"]:
            resposta["NextContinuationToken"] = pagina[-1]
        return resposta

    NEGAR_DELETE = False  # simula role sem s3:DeleteObject (o S3 responde 200 com Errors por arquivo)

    def delete_objects(self, **kw):
        validar("s3", "DeleteObjects", kw)
        if FakeS3.NEGAR_DELETE:
            return {"Errors": [{"Key": o["Key"], "Code": "AccessDenied", "Message": "Access Denied"}
                               for o in kw["Delete"]["Objects"]]}
        for obj in kw["Delete"]["Objects"]:
            caminho = self._caminho(kw["Bucket"], obj["Key"])
            if os.path.isfile(caminho):
                os.remove(caminho)
            pasta = os.path.dirname(caminho)
            while pasta.startswith(RAIZ_S3 + "/") and os.path.isdir(pasta) and not os.listdir(pasta):
                os.rmdir(pasta)  # S3 não tem pastas: some junto com o último arquivo
                pasta = os.path.dirname(pasta)
        return {"Deleted": kw["Delete"]["Objects"]}


class FakeGlue:
    def get_table(self, **kw):
        validar("glue", "GetTable", kw)
        con = conexao_trino()
        cur = con.cursor()
        cur.execute("SELECT count(*) FROM hive.information_schema.tables WHERE table_schema = ? AND table_name = ?",
                    [kw["DatabaseName"], kw["Name"]])
        existe = cur.fetchall()[0][0] > 0
        con.close()
        if not existe:
            raise erro("EntityNotFoundException", "Table " + kw["Name"] + " not found.", "GetTable")
        return {"Table": {"Name": kw["Name"], "DatabaseName": kw["DatabaseName"]}}


def instalar(athena):
    """Troca boto3.client pelos falsos e o awswrangler.s3.to_parquet por uma gravação local com o mesmo contrato."""
    import inspect
    import awswrangler as wr
    import pyarrow as pa
    import pyarrow.parquet as pq

    s3, glue = FakeS3(), FakeGlue()
    original_client = boto3.client

    def cliente(nome, *a, **kw):
        return {"athena": athena, "s3": s3, "glue": glue}.get(nome) or original_client(nome, *a, **kw)
    boto3.client = cliente

    real = wr.s3.to_parquet
    gravacoes = []

    def to_parquet_local(**kw):
        inspect.signature(real).bind(**kw)  # mesmos argumentos aceitos pelo awswrangler 2.15.1
        df = kw["df"]
        destino = kw["path"].replace("s3://", RAIZ_S3 + "/")
        for safra, parte in df.groupby("safra"):
            pasta = os.path.join(destino, "safra=" + str(safra))
            os.makedirs(pasta, exist_ok=True)
            tabela = pa.Table.from_pandas(parte.drop(columns=["safra"]), preserve_index=False)
            pq.write_table(tabela, os.path.join(pasta, uuid.uuid4().hex + ".snappy.parquet"), compression="snappy")
        gravacoes.append({"table": kw["table"], "database": kw["database"], "rows": len(df), "dtype": kw["dtype"]})
        return {"paths": [], "partitions_values": {}}
    wr.s3.to_parquet = to_parquet_local
    return {"s3": s3, "glue": glue, "gravacoes_logs": gravacoes}
