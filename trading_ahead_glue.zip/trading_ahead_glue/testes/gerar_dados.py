"""Gera as fontes simuladas (mesmos nomes de banco, tabela e coluna usados pelas CTAs) e registra no Trino.

Cenários plantados (safra alvo 202509, histórico 202503 a 202508):
  * cada mês do histórico tem 2 eventos atípicos (salto de +-10% no preço) com clientes PF e PJ operando antes e
    revertendo depois, para o P99 ter amostra dos dois públicos;
  * 202509 / PETR4 ALTA em 17/09: PF "grande" (2 vínculos societários -> deve virar 1 alerta com qtd_vinculos = 2),
    PF "médio" (abaixo do corte), PF que vendeu só metade (reversão < 75% -> NÃO ALERTA) e PJ repasse_enviado grande;
  * 202509 / VALE3 QUEDA em 23/09: PF que vendeu antes e recomprou depois (reversão 100% pela custódia D-15);
  * 202509 / WEGE3 ALTA em 10/09 com Fato Relevante no mesmo dia -> evento descartado na CTA3;
  * 202509 / BBDC4 QUEDA em 02/09: evento no começo do mês, sem custódia D-15 na janela da CTA14 ('Não consta');
  * empresa com CNPJ começando em zero (Banco do Brasil, BBAS3) para conferir a normalização de CNPJ da CTA6.
"""
import math
import os
import random
import shutil
from datetime import date, timedelta

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

from fake_aws import RAIZ_S3, conexao_trino

random.seed(7)
np.random.seed(7)
FONTES = RAIZ_S3 + "/fontes"
INICIO, FIM = date(2024, 2, 1), date(2025, 10, 20)
FERIADOS = {date(2024, 3, 29), date(2024, 5, 1), date(2024, 5, 30), date(2024, 11, 15), date(2024, 11, 20),
            date(2024, 12, 24), date(2024, 12, 25), date(2024, 12, 31), date(2025, 1, 1), date(2025, 3, 3),
            date(2025, 3, 4), date(2025, 4, 18), date(2025, 4, 21), date(2025, 5, 1), date(2025, 6, 19)}
DIAS = [INICIO + timedelta(days=i) for i in range((FIM - INICIO).days + 1)]
UTEIS = [d for d in DIAS if d.weekday() < 5 and d not in FERIADOS]
POS = {d: i for i, d in enumerate(UTEIS)}

EMPRESAS = {  # ticker 4 letras -> (cnpj, nome)
    "PETR": ("33000167000101", "PETROLEO BRASILEIRO S.A."), "VALE": ("33592510000154", "VALE S.A."),
    "ITUB": ("60872504000123", "ITAU UNIBANCO HOLDING S.A."), "BBDC": ("60746948000112", "BANCO BRADESCO S.A."),
    "ABEV": ("07526557000100", "AMBEV S.A."), "WEGE": ("84429695000111", "WEG S.A."),
    "MGLU": ("47960950000121", "MAGAZINE LUIZA S.A."), "BBAS": ("00000000000191", "BANCO DO BRASIL S.A."),
}
ATIVOS = ["PETR4", "VALE3", "ITUB4", "BBDC4", "ABEV3", "WEGE3", "MGLU3", "BBAS3", "HGLG11"]
EVENTOS = [  # (ativo, data, direção)
    ("PETR4", date(2025, 3, 18), +1), ("VALE3", date(2025, 3, 25), -1),
    ("ITUB4", date(2025, 4, 15), +1), ("ABEV3", date(2025, 4, 24), +1),
    ("WEGE3", date(2025, 5, 14), +1), ("BBDC4", date(2025, 5, 22), -1),
    ("MGLU3", date(2025, 6, 11), +1), ("PETR4", date(2025, 6, 24), -1),
    ("VALE3", date(2025, 7, 16), +1), ("ITUB4", date(2025, 7, 23), -1),
    ("ABEV3", date(2025, 8, 13), +1), ("BBAS3", date(2025, 8, 20), +1),
    ("PETR4", date(2025, 9, 17), +1), ("VALE3", date(2025, 9, 23), -1),
    ("WEGE3", date(2025, 9, 10), +1), ("BBDC4", date(2025, 9, 2), -1),
]
FATO_RELEVANTE = [("WEGE", date(2025, 9, 10))]


def util(d, deslocamento):
    return UTEIS[POS[d] + deslocamento]


# ---------------------------------------------------------------- preços
precos = {}
for ativo in ATIVOS:
    nivel = random.uniform(15, 45)
    sigma = 0.004 if ativo.endswith("11") else 0.01
    serie = {}
    saltos = {d: s for a, d, s in EVENTOS if a == ativo}
    for d in UTEIS:
        r = np.random.normal(0, sigma)
        if d in saltos:
            r = 0.10 * saltos[d]
        nivel *= math.exp(r)
        serie[d] = round(nivel, 2)
    precos[ativo] = serie

linhas_preco = []
for ativo, serie in precos.items():
    for d, p in serie.items():
        linhas_preco.append({"dat_base_info": d.strftime("%Y%m%d"), "nom_ativ_finn": ativo, "vlr_atbt": p,
                             "idt_atbt": "11", "nom_font_info": "B3", "timestamp": "1700000000", "versao": "1"})
        if random.random() < 0.02:  # versão antiga do mesmo preço: a CTA1 deve ficar com a mais nova
            linhas_preco.append({"dat_base_info": d.strftime("%Y%m%d"), "nom_ativ_finn": ativo, "vlr_atbt": p * 0.5,
                                 "idt_atbt": "11", "nom_font_info": "B3", "timestamp": "1600000000", "versao": "0"})
        if random.random() < 0.01:  # outro atributo do mesmo ativo: deve ser ignorado
            linhas_preco.append({"dat_base_info": d.strftime("%Y%m%d"), "nom_ativ_finn": ativo, "vlr_atbt": 9999.0,
                                 "idt_atbt": "12", "nom_font_info": "B3", "timestamp": "1700000000", "versao": "1"})

# ---------------------------------------------------------------- clientes e cadastro
clientes = {}


def novo_cliente(codigo, pf, apelido=None):
    doc = (f"{random.randint(10**9, 10**10 - 1):011d}" if pf else f"{random.randint(10**12, 10**13 - 1):014d}")
    clientes[codigo] = {"codigo": codigo, "doc": doc, "pf": pf, "apelido": apelido or f"cli{codigo}"}
    return codigo


operacoes, custodia_mov = [], []  # custodia_mov: (codigo, ativo, data_liquidacao, delta)


def operar(codigo, ativo, d, lado, qtd, origem="local"):
    preco = precos[ativo][d]
    operacoes.append({"cliente": codigo, "conta_negociacao": codigo, "conta_master": codigo, "lado": lado,
                      "ativo": ativo, "preco": float(preco), "quantidade": int(qtd),
                      "volume_negociado": round(preco * qtd, 2), "mercado": "XBSP",
                      "data_pregao": d.isoformat() + " 00:00:00.000", "ano_pregao": d.strftime("%Y"),
                      "mes_pregao": d.strftime("%m"), "dia_pregao": d.strftime("%d"),
                      "hora_transacao": f"{random.randint(10, 17):02d}:{random.randint(0, 59):02d}:00",
                      "broker": "XP" if random.random() < 0.5 else "ITAU", "tipo_operacao": origem})
    custodia_mov.append((codigo, ativo, util(d, 2), qtd if lado == "Compra" else -qtd))


def caso_alta(codigo, ativo, d, qtd, fracao_venda=1.0, origem="local"):
    operar(codigo, ativo, util(d, -8), "Compra", qtd // 2, origem)
    operar(codigo, ativo, util(d, -4), "Compra", qtd - qtd // 2, origem)
    vender = int(qtd * fracao_venda)
    if vender:
        operar(codigo, ativo, util(d, 1), "Venda", vender // 2, origem)
        operar(codigo, ativo, util(d, 2), "Venda", vender - vender // 2, origem)


def caso_queda(codigo, ativo, d, qtd, origem="local"):
    operar(codigo, ativo, util(d, -70), "Compra", qtd, origem)  # posição antiga (perfil histórico + custódia)
    operar(codigo, ativo, util(d, -6), "Venda", qtd // 2, origem)
    operar(codigo, ativo, util(d, -3), "Venda", qtd - qtd // 2, origem)
    operar(codigo, ativo, util(d, 1), "Compra", qtd // 2, origem)
    operar(codigo, ativo, util(d, 2), "Compra", qtd - qtd // 2, origem)


seq = iter(range(100001, 199999))
seq_pj = iter(range(200001, 299999))
for ativo, d, direcao in EVENTOS:
    if d >= date(2025, 9, 1):
        continue
    for _ in range(3):  # PF do histórico com tamanhos variados
        c = novo_cliente(str(next(seq)), True)
        qtd = random.choice([2000, 5000, 9000, 14000, 20000, 26000])
        (caso_alta if direcao > 0 else caso_queda)(c, ativo, d, qtd)
    c = novo_cliente(str(next(seq_pj)), False)
    if direcao > 0:
        caso_alta(c, ativo, d, random.choice([60000, 90000, 120000]), fracao_venda=0.2, origem="repasse_enviado")
    else:
        caso_queda(c, ativo, d, random.choice([20000, 40000]), origem="repasse_enviado")

grande = novo_cliente("300001", True, "socio relevante")
caso_alta(grande, "PETR4", date(2025, 9, 17), 120000)
medio = novo_cliente("300002", True)
caso_alta(medio, "PETR4", date(2025, 9, 17), 30000)
metade = novo_cliente("300003", True)
caso_alta(metade, "PETR4", date(2025, 9, 17), 100000, fracao_venda=0.5)
pj_grande = novo_cliente("400001", False)
caso_alta(pj_grande, "PETR4", date(2025, 9, 17), 400000, fracao_venda=0.2, origem="repasse_enviado")
vendedor = novo_cliente("300004", True)
caso_queda(vendedor, "VALE3", date(2025, 9, 23), 90000)
fr = novo_cliente("300005", True)
caso_alta(fr, "WEGE3", date(2025, 9, 10), 150000)
inicio_mes = novo_cliente("300006", True)
caso_queda(inicio_mes, "BBDC4", date(2025, 9, 2), 90000)
for _ in range(25):  # ruído: operações pequenas em datas aleatórias
    c = novo_cliente(str(next(seq)), random.random() < 0.8)
    ativo = random.choice(ATIVOS[:8])
    d = random.choice([x for x in UTEIS if date(2025, 2, 1) <= x <= date(2025, 9, 30)])
    operar(c, ativo, d, random.choice(["Compra", "Venda"]), random.choice([100, 300, 800]))

complementos = []
for c in clientes.values():
    for ref in ("2025-09-30", "2025-10-31"):  # duas fotos: as CTAs usam a mais recente
        complementos.append({"codigo_conta": int(c["codigo"]), "cpf_cnpj": c["doc"], "tipo_cliente": "Normal",
                             "tipo_investidor": "Varejo" if c["pf"] else "Institucional",
                             "pessoa_fisica": "true" if c["pf"] else "false",
                             "ultima_atualizacao": "2025-01-10", "data_referencia": ref, "apelido": c["apelido"]})
liger = [{"cd_cpfcgc": c["doc"], "in_politico_exp": "N", "in_pess_vinc": "N", "dt_atualiz": "2025-01-10",
          "ano_carga_ptc": 2025, "mes_carga_ptc": 10, "dia_carga_ptc": 15} for c in clientes.values()]

# ---------------------------------------------------------------- vínculos (CVM FRE) e base de tickers
doc_grande = clientes[grande]["doc"]
cpf_fmt = f"{doc_grande[:3]}.{doc_grande[3:6]}.{doc_grande[6:9]}-{doc_grande[9:]}"
adm = [{"cpf": cpf_fmt, "cnpj_companhia": "33.000.167/0001-01", "cargo_eletivo_ocupado": "Conselheiro"}]
comite = [{"cpf": cpf_fmt, "cnpj_companhia": "00.000.000/0001-91", "cargo_ocupado": "Membro do comitê"}]
vazio_part = [{"cnpj": "11111111000111", "cnpj_companhia": "99.999.999/0001-99", "razao_social": "X"}]
vazio_pos = [{"cpf_cnpj_acionista": "22222222222", "cnpj_companhia": "99.999.999/0001-99", "acionista_relacionado": "X"}]
vazio_fam = [{"cpf_pessoa_relacionada": "33333333333", "cnpj_companhia": "99.999.999/0001-99", "cargo_pessoa_relacionada": "X"}]
vazio_sub = [{"cpf_administrador": "44444444444", "cnpj_companhia": "99.999.999/0001-99", "cargo_administrador": "X"}]
empregador = [{"cpf_cnpj": "55555555555", "cnpj_empresa_empregadora": "99999999000199"}]
ticker = [{"cnpj_companhia": str(int(cnpj)) + ".0", "ticker_4letras": t, "nome_empresarial": nome,
           "ano_captura": 2025, "mes_captura": 10} for t, (cnpj, nome) in EMPRESAS.items()]
ipe = [{"cnpj_companhia": f"{EMPRESAS[t][0][:2]}.{EMPRESAS[t][0][2:5]}.{EMPRESAS[t][0][5:8]}/{EMPRESAS[t][0][8:12]}-{EMPRESAS[t][0][12:]}",
        "data_entrega": d, "versao": 1, "categoria": "Fato Relevante", "tipo": "Fato Relevante"} for t, d in FATO_RELEVANTE]
ipe.append({"cnpj_companhia": "60.872.504/0001-23", "data_entrega": date(2025, 9, 5), "versao": 1,
            "categoria": "Comunicado ao Mercado", "tipo": "Outros"})

# ---------------------------------------------------------------- custódia diária (D+2), só dias úteis
mov = pd.DataFrame(custodia_mov, columns=["codigo", "ativo", "data", "delta"])
custodia = []
for (codigo, ativo), grupo in mov.groupby(["codigo", "ativo"]):
    if not clientes[codigo]["pf"]:
        continue
    deltas = grupo.groupby("data")["delta"].sum().to_dict()
    posicao = 0
    for d in UTEIS:
        posicao += deltas.get(d, 0)
        if d >= date(2025, 1, 1):
            custodia.append({"data_referencia": d.isoformat(), "codigo_conta": int(codigo), "ativo": ativo,
                             "quantidade_d0": int(posicao)})

# ---------------------------------------------------------------- gravação + registro no Trino
TABELAS = {
    ("db_corp_gestaoderiscos_distribuiprecoscorporativos_sor_01", "tbim8_acao_btres"): (linhas_preco, {
        "dat_base_info": "varchar", "nom_ativ_finn": "varchar", "vlr_atbt": "double", "idt_atbt": "varchar",
        "nom_font_info": "varchar", "timestamp": "varchar", "versao": "varchar"}),
    ("db_corp_gestaoderiscos_alertastradesurveillance_sor_01", "tb_rss_base_ticker_sor"): (ticker, {
        "cnpj_companhia": "varchar", "ticker_4letras": "varchar", "nome_empresarial": "varchar",
        "ano_captura": "integer", "mes_captura": "integer"}),
    ("db_corp_modelagem_historicalmarketdata_sor_01", "tb_wa5_sor_br_gov_cvm_ipe_cia_aberta"): (ipe, {
        "cnpj_companhia": "varchar", "data_entrega": "date", "versao": "integer", "categoria": "varchar", "tipo": "varchar"}),
    ("db_corp_corretora_inoabrokertools_sot_01", "tb_ep7_alocacoes_sot"): (operacoes, {
        "cliente": "varchar", "conta_negociacao": "varchar", "conta_master": "varchar", "lado": "varchar",
        "ativo": "varchar", "preco": "double", "quantidade": "bigint", "volume_negociado": "double",
        "mercado": "varchar", "data_pregao": "varchar", "ano_pregao": "varchar", "mes_pregao": "varchar",
        "dia_pregao": "varchar", "hora_transacao": "varchar", "broker": "varchar", "tipo_operacao": "varchar"}),
    ("db_corp_corretora_inoabrokertools_sot_01", "tb_ep7_complementos_contas_sot"): (complementos, {
        "codigo_conta": "bigint", "cpf_cnpj": "varchar", "tipo_cliente": "varchar", "tipo_investidor": "varchar",
        "pessoa_fisica": "varchar", "ultima_atualizacao": "varchar", "data_referencia": "varchar", "apelido": "varchar"}),
    ("db_corp_corretora_sinacor_sor_01", "tb_eg9_tsccliger"): (liger, {
        "cd_cpfcgc": "varchar", "in_politico_exp": "varchar", "in_pess_vinc": "varchar", "dt_atualiz": "varchar",
        "ano_carga_ptc": "integer", "mes_carga_ptc": "integer", "dia_carga_ptc": "integer"}),
    ("db_corp_modelagem_historicalmarketdata_sor_01", "tb_wa5_sor_br_gov_cvm_fre_cia_aberta_administrador_membro_conselho_fiscal"): (adm, {
        "cpf": "varchar", "cnpj_companhia": "varchar", "cargo_eletivo_ocupado": "varchar"}),
    ("db_corp_modelagem_historicalmarketdata_sor_01", "tb_wa5_sor_br_gov_cvm_fre_cia_aberta_membro_comite"): (comite, {
        "cpf": "varchar", "cnpj_companhia": "varchar", "cargo_ocupado": "varchar"}),
    ("db_corp_modelagem_historicalmarketdata_sor_01", "tb_wa5_sor_br_gov_cvm_fre_cia_aberta_participacao_sociedade"): (vazio_part, {
        "cnpj": "varchar", "cnpj_companhia": "varchar", "razao_social": "varchar"}),
    ("db_corp_modelagem_historicalmarketdata_sor_01", "tb_wa5_sor_br_gov_cvm_fre_cia_aberta_posicao_acionaria"): (vazio_pos, {
        "cpf_cnpj_acionista": "varchar", "cnpj_companhia": "varchar", "acionista_relacionado": "varchar"}),
    ("db_corp_modelagem_historicalmarketdata_sor_01", "tb_wa5_sor_br_gov_cvm_fre_cia_aberta_relacao_familiar"): (vazio_fam, {
        "cpf_pessoa_relacionada": "varchar", "cnpj_companhia": "varchar", "cargo_pessoa_relacionada": "varchar"}),
    ("db_corp_modelagem_historicalmarketdata_sor_01", "tb_wa5_sor_br_gov_cvm_fre_cia_aberta_relacao_subordinacao"): (vazio_sub, {
        "cpf_administrador": "varchar", "cnpj_companhia": "varchar", "cargo_administrador": "varchar"}),
    ("db_corp_corretora_inoabrokertools_sor_01", "tb_ep7_re_complementos_investidores_sor"): (empregador, {
        "cpf_cnpj": "varchar", "cnpj_empresa_empregadora": "varchar"}),
    ("db_corp_corretora_inoabrokertools_sot_01", "tb_ep7_carteiras_equities_sot"): (custodia, {
        "data_referencia": "varchar", "codigo_conta": "bigint", "ativo": "varchar", "quantidade_d0": "bigint"}),
}
PA = {"varchar": pa.string(), "double": pa.float64(), "bigint": pa.int64(), "integer": pa.int32(), "date": pa.date32()}


def main():
    shutil.rmtree(FONTES, ignore_errors=True)
    con = conexao_trino()
    cur = con.cursor()
    for banco in sorted({b for b, _ in TABELAS} | {"workspace_db"}):
        cur.execute(f"CREATE SCHEMA IF NOT EXISTS hive.{banco} WITH (location = 'local:///warehouse/{banco}')")
        cur.fetchall()
    for (banco, tabela), (linhas, tipos) in TABELAS.items():
        pasta = f"{FONTES}/{banco}/{tabela}"
        os.makedirs(pasta)
        esquema = pa.schema([(c, PA[t]) for c, t in tipos.items()])
        pq.write_table(pa.Table.from_pylist(linhas, schema=esquema), pasta + "/dados.parquet")
        cur.execute(f"DROP TABLE IF EXISTS hive.{banco}.{tabela}")
        cur.fetchall()
        colunas = ", ".join(f'"{c}" {t}' for c, t in tipos.items())
        cur.execute(f"CREATE TABLE hive.{banco}.{tabela} ({colunas}) WITH (format = 'PARQUET', "
                    f"external_location = 'local:///s3/fontes/{banco}/{tabela}')")
        cur.fetchall()
        print(f"{banco}.{tabela}: {len(linhas)} linhas")
    con.close()


if __name__ == "__main__":
    main()
