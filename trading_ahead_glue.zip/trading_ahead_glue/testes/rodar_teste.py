"""Roda o orquestrador de ponta a ponta contra o Athena simulado (Trino) e confere os resultados."""
import glob
import importlib
import json
import os
import shutil
import sys
from datetime import datetime

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(__file__))
import fake_aws  # noqa: E402

ENTREGA = "/home/claude/entrega/trading_ahead_glue"
BUCKET = "itau-self-wkp-sa-east-1-886436964833"
BASE = f"{fake_aws.RAIZ_S3}/{BUCKET}/TRADING_AHEAD"
ARGS_GLUE = ["main_trading_ahead.py", "--JOB_ID", "j_123", "--JOB_RUN_ID", "jr_teste", "--JOB_NAME", "trading-ahead-hml",
             "--job-bookmark-option", "job-bookmark-disable", "--TempDir", f"s3://{BUCKET}/TRADING_AHEAD/temp/",
             "--enable-job-insights", "false", "--library-set", "analytics", "--scriptLocation", "s3://x/y.py"]
resultados = []


def checar(nome, condicao, detalhe=""):
    resultados.append((nome, bool(condicao), detalhe))
    print(("OK   " if condicao else "FALHOU ") + nome + (f"  [{detalhe}]" if detalhe else ""), flush=True)


def sql_trino(consulta):
    con = fake_aws.conexao_trino("workspace_db")
    cur = con.cursor()
    cur.execute(consulta)
    linhas, colunas = cur.fetchall(), [d[0] for d in (cur.description or [])]
    con.close()
    return pd.DataFrame(linhas, columns=colunas)


def limpar_ambiente():
    for pasta in ("ctas", "logs", "temp"):
        shutil.rmtree(f"{BASE}/{pasta}", ignore_errors=True)
    shutil.rmtree(f"{BASE}/sql", ignore_errors=True)
    shutil.copytree(f"{ENTREGA}/sql", f"{BASE}/sql")
    for t in sql_trino("SHOW TABLES FROM hive.workspace_db")["Table"]:
        sql_trino(f"DROP TABLE hive.workspace_db.{t}")


def carregar_orquestrador(athena):
    contexto = fake_aws.instalar(athena)
    sys.path.insert(0, f"{ENTREGA}/scripts")
    modulo = importlib.import_module("main_trading_ahead")
    modulo = importlib.reload(modulo)
    modulo.INTERVALO_CONSULTA_S = 0
    return modulo, contexto


def ler_logs(tipo):
    arquivos = glob.glob(f"{BASE}/logs/hml/log_{tipo}/safra=*/*.parquet")
    partes = []
    for a in arquivos:
        df = pd.read_parquet(a)
        df["safra"] = a.split("safra=")[1].split("/")[0]
        partes.append(df)
    return pd.concat(partes, ignore_index=True) if partes else pd.DataFrame()


def p99_numpy(valores):
    return float(np.quantile(np.array(sorted(valores), dtype=float), 0.99))  # método linear padrão do numpy


def main():
    limpar_ambiente()

    # ---------------------------------------------------------------- 1) parâmetros e safra automática
    athena = fake_aws.FakeAthena()
    m, ctx = carregar_orquestrador(athena)
    cfg = m.configurar(ARGS_GLUE + ["--AMBIENTE", "prd"], agora=datetime(2026, 11, 10, 9, 0, tzinfo=m.FUSO_BRASIL))
    checar("safra auto = mês anterior (rodando em 10/11/2026)", cfg["SAFRA"] == "202610", cfg["SAFRA"])
    try:
        m.configurar(ARGS_GLUE + ["--AMBIENTE", "prd"], agora=datetime(2026, 11, 3, 9, 0, tzinfo=m.FUSO_BRASIL))
        checar("safra auto bloqueada antes de fim do mês + 7", False)
    except ValueError as e:
        checar("safra auto bloqueada antes de fim do mês + 7", "2026-11-08" in str(e), str(e))
    checar("parâmetros extras do Glue são ignorados", cfg["ID_TENTATIVA"] == "jr_teste" and cfg["JOB_NAME"] == "trading-ahead-hml")
    checar("caminhos derivados", cfg["S3_CTAS"] == f"s3://{BUCKET}/TRADING_AHEAD/ctas/prd/" and cfg["PREFIXO_TABELA"] == "prd_")

    # ---------------------------------------------------------------- 2) modo plano
    r = m.main(ARGS_GLUE + ["--AMBIENTE", "hml", "--SAFRA", "202509", "--MODO", "plano"])
    planos = glob.glob(f"{BASE}/temp/plano/{r['id_execucao']}/*.sql")
    checar("plano: nenhuma consulta no Athena", len(athena.consultas) == 0, str(len(athena.consultas)))
    checar("plano: 7 safras x 12 + 1 + 9 + 4 SQLs gravadas", len(planos) == 7 * 12 + 1 + 9 + 4, str(len(planos)))
    checar("plano: nenhum {{ }} sobrando", not any("{{" in open(p).read() for p in planos))
    checar("plano: resumo da execução gravado", os.path.isfile(f"{BASE}/logs/hml/execucoes/{r['id_execucao']}.json"))

    # ---------------------------------------------------------------- 3) execução completa (safra antiga 202509)
    r = m.main(ARGS_GLUE + ["--AMBIENTE", "hml", "--SAFRA", "202509", "--MODO", "executar"])
    checar("execução: status SUCESSO", r["status"] == "SUCESSO")
    checar("execução: 6 safras de histórico calculadas", r["safras_calculadas"] == ["202503", "202504", "202505", "202506", "202507", "202508"], str(r["safras_calculadas"]))
    print(json.dumps({k: r[k] for k in ("alertas_pf", "alertas_pj", "cortes")}, indent=1, default=str))

    # P99 conferido de forma independente (numpy sobre as tabelas da CTA13 base de cada safra)
    meses = r["safras_calculadas"]
    hist = pd.concat([sql_trino(f"SELECT * FROM hml_cta13_calculoresultado_base_estudo_{mm}") for mm in meses], ignore_index=True)
    hist["data_evento"] = pd.to_datetime(hist["data_evento"]).dt.date
    hist = hist[(hist["data_evento"] >= pd.Timestamp("2025-03-03").date()) & (hist["data_evento"] <= pd.Timestamp("2025-08-31").date())].copy()
    hist["ativo_negociado_4letras"] = hist["ativo_negociado"].str[:4]
    hist["diferenca_volume"] = (hist["soma_volume_venda_15dias"] - hist["soma_volume_compra_15dias"]).abs()
    chave = list(m.CHAVE_ALERTA)
    dedup = hist[chave].drop_duplicates()
    for codigo, publico in (("F", "PF"), ("J", "PJ")):
        valores = dedup.loc[(dedup["tipo_pessoa"] == codigo) & dedup["resultado"].notna(), "resultado"].tolist()
        esperado = p99_numpy(valores)
        obtido = r["cortes"][publico]["p99"]
        checar(f"P99 {publico} igual ao numpy.quantile (n={len(valores)})", abs(esperado - obtido) < 1e-6, f"{obtido:.4f} vs {esperado:.4f}")
        checar(f"corte {publico} = max(P99, 100 mil)", r["cortes"][publico]["cutoff"] == max(esperado, 100000.0))
    checar("calibração deduplicou os vínculos (linhas brutas > chave única)", len(hist) >= len(dedup), f"{len(hist)} brutas / {len(dedup)} únicas")

    # Alertas finais conferidos de forma independente
    for publico, origem in (("PF", "cta18_alertastradingahead_pf_202509"), ("PJ", "cta19_proxyreversaocustodia_202509")):
        fonte = sql_trino(f"SELECT * FROM hml_{origem}")
        fonte["ativo_negociado_4letras"] = fonte["ativo_negociado"].str[:4]
        fonte["diferenca_volume"] = (fonte["soma_volume_venda_15dias"] - fonte["soma_volume_compra_15dias"]).abs()
        corte = r["cortes"][publico]["cutoff"]
        esperado = fonte[(fonte["resultado_final"] == "ALERTA") & (fonte["resultado"] > corte)][chave].drop_duplicates()
        final = sql_trino(f"SELECT * FROM hml_alertas_tradingahead_{publico.lower()}_202509")
        checar(f"alertas {publico}: quantidade bate com o recálculo independente", len(final) == len(esperado), f"{len(final)} vs {len(esperado)}")
        checar(f"alertas {publico}: id_alerta único", final["id_alerta"].is_unique)
        checar(f"alertas {publico}: todos acima do corte", bool((final["resultado"] > corte).all()) if len(final) else True)

    pf = sql_trino("SELECT codigo_cliente, ativo_negociado, resultado, qtd_vinculos, reversao FROM hml_alertas_tradingahead_pf_202509")
    pj = sql_trino("SELECT codigo_cliente, resultado, reversao_pj FROM hml_alertas_tradingahead_pj_202509")
    print(pf.to_string(index=False)); print(pj.to_string(index=False))
    grande = pf[pf["codigo_cliente"] == "300001"]
    checar("cenário: PF com 2 vínculos vira 1 alerta com qtd_vinculos = 2", len(grande) == 1 and int(grande["qtd_vinculos"].iloc[0]) == 2)
    checar("cenário: PF que vendeu metade (reversão 50%) não alerta", "300003" not in set(pf["codigo_cliente"]))
    checar("cenário: PF médio abaixo do corte não alerta", "300002" not in set(pf["codigo_cliente"]))
    checar("cenário: PF da QUEDA (vendeu antes, recomprou depois) alerta", "300004" in set(pf["codigo_cliente"]))
    checar("cenário: PJ repasse_enviado grande alerta", "400001" in set(pj["codigo_cliente"]))
    eventos = sql_trino("SELECT ativo_atipico, data_evento FROM hml_cta3_eventosatipicos_202509")
    checar("cenário: WEGE3 com Fato Relevante foi descartado na CTA3", "WEGE3" not in set(eventos["ativo_atipico"]), str(sorted(set(eventos["ativo_atipico"]))))
    nc = sql_trino("SELECT DISTINCT ativo, custodia_d_15, reversao, resultado_final FROM hml_cta18_custodiareversao_202509 WHERE ativo = 'BBDC4'")
    checar("cenário: BBDC4 em 02/09 fica 'Não consta' na custódia D-15 e vira ALERTA", len(nc) > 0 and (nc["custodia_d_15"] == "Não consta").all() and (nc["resultado_final"] == "ALERTA").all(), nc.to_dict("records").__str__()[:200])
    bb = sql_trino("SELECT DISTINCT ticker_empresa_vinculada, cnpj_empresa_vinculada FROM hml_cta6_operacoes_202509 WHERE codigo_cliente = '300001'")
    checar("achado CTA6: empresa com CNPJ iniciado em 0 (BB) fica 'Não consta' na base de ticker", "Não consta" in set(bb["ticker_empresa_vinculada"]), bb.to_dict("records").__str__())
    perc = sql_trino("SELECT DISTINCT perc_reversao_pre FROM hml_cta13_calculoresultado_base_estudo_202509 WHERE codigo_cliente = '300003'")
    checar("achado CTA13: perc_reversao_pre sai inteiro (divisão inteira)", perc["perc_reversao_pre"].dropna().apply(lambda v: float(v).is_integer()).all(), str(perc["perc_reversao_pre"].tolist()))

    # Logs no padrão original
    resumo, detalhe = ler_logs("resumo"), ler_logs("detalhe")
    esperados = {"inicio_execucao", "consulta", "volumetria", "tempo_etapa", "base_fonte_vazia", "nulo", "tipo_dado",
                 "dominio", "nao_finito", "versoes_preco", "repeticao_campos_observados", "duplicata_chave_contagem",
                 "nulo_resultado", "resultado_negativo", "resultado_zero", "calibracao_p99", "invalid_count",
                 "duplicate_ids", "cobertura_etapas", "status_execucao"}
    exec_id = r["id_execucao"]
    tipos = set(resumo.loc[resumo["id_execucao"] == exec_id, "tipo_verificacao"])
    checar("logs: todos os tipos de verificação do original aparecem", esperados <= tipos, str(sorted(esperados - tipos)))
    checar("logs: colunas exatamente no padrão original", list(resumo.columns[:-1]) == [c for c in m.COLS_LOG_RESUMO if c != "safra"] + list(m.EXTRA_LOG_TYPES), str(list(resumo.columns)))
    checar("logs: nenhum GATE numa execução bem-sucedida", not ((resumo["id_execucao"] == exec_id) & (resumo["acao"] == "GATE")).any())
    checar("logs: particionados por safra (histórico e alvo)", {"202503", "202509"} <= set(resumo["safra"]))
    checar("logs: detalhe do P99 por público", len(detalhe[(detalhe["id_execucao"] == exec_id) & (detalhe["tipo_verificacao"] == "calibracao_p99")]) == 2)
    checar("logs: consultas com query_id, tempo e bytes", resumo.loc[(resumo["id_execucao"] == exec_id) & (resumo["tipo_verificacao"] == "consulta"), ["query_id", "tempo_total_s", "bytes_lidos"]].notna().all().all())
    checar("logs: resumo JSON da execução", json.load(open(f"{BASE}/logs/hml/execucoes/{exec_id}.json"))["status"] == "SUCESSO")
    checar("consultas usam temp/athena como saída", all(e["saida"].startswith(f"s3://{BUCKET}/TRADING_AHEAD/temp/athena/") for e in athena.execucoes.values()))
    checar("destinos das CTAs ficaram em ctas/hml/", os.path.isdir(f"{BASE}/ctas/hml/CTA1_Precos_202509") and not glob.glob(f"{BASE}/ctas/CTA*"))
    n_primeira = len(athena.consultas)

    # ---------------------------------------------------------------- 4) segunda execução: reaproveita histórico
    r2 = m.main(ARGS_GLUE + ["--AMBIENTE", "hml", "--SAFRA", "202509", "--MODO", "executar"])
    checar("reexecução: histórico reaproveitado (0 safras recalculadas)", r2["safras_calculadas"] == [] and len(r2["safras_reaproveitadas"]) == 6)
    checar("reexecução: mesmos cortes e alertas (DROP + CTAS idempotente)", r2["cortes"] == r["cortes"] and r2["alertas_pf"] == r["alertas_pf"] and r2["alertas_pj"] == r["alertas_pj"])
    checar("reexecução: bem menos consultas", len(athena.consultas) - n_primeira < n_primeira / 3, f"{len(athena.consultas) - n_primeira} vs {n_primeira}")
    linhas_1 = {(t["safra"], t["etapa"]): t["linhas"] for t in r["tabelas"] if t["safra"] == "202509"}
    linhas_2 = {(t["safra"], t["etapa"]): t["linhas"] for t in r2["tabelas"]}
    checar("reexecução: mesma volumetria em todas as etapas da safra alvo (destino limpo antes do CTAS)",
           linhas_1 == linhas_2, str({k: (linhas_1.get(k), linhas_2.get(k)) for k in linhas_1 if linhas_1.get(k) != linhas_2.get(k)}))
    checar("reexecução: arquivos antigos foram apagados antes de cada CTAS",
           all(t["arquivos_antigos_apagados"] > 0 for t in r2["tabelas"] if t["linhas"] > 0), "")

    # ---------------------------------------------------------------- 4b) role sem DeleteObject: para com mensagem clara
    fake_aws.FakeS3.NEGAR_DELETE = True
    try:
        m.main(ARGS_GLUE + ["--AMBIENTE", "hml", "--SAFRA", "202509", "--MODO", "executar"])
        checar("sem permissão de apagar: para antes do CTAS com mensagem clara", False)
    except m.ErroExecucao as e:
        checar("sem permissão de apagar: para antes do CTAS com mensagem clara", "AccessDenied" in str(e) and "antes do CTAS" in str(e), str(e)[:140])
    finally:
        fake_aws.FakeS3.NEGAR_DELETE = False

    # ---------------------------------------------------------------- 5) falha no meio: logs dizem onde, como e quando
    athena_falha = fake_aws.FakeAthena(falhar_etapa_contendo="CTA16_CustodiaInfos")
    m, ctx = carregar_orquestrador(athena_falha)
    try:
        m.main(ARGS_GLUE + ["--AMBIENTE", "hml", "--SAFRA", "202509", "--MODO", "executar"])
        checar("falha: exceção propagada para o Glue marcar FAILED", False)
    except m.ErroExecucao as e:
        checar("falha: exceção propagada para o Glue marcar FAILED", "cta16" in str(e), str(e)[:120])
    resumo, detalhe = ler_logs("resumo"), ler_logs("detalhe")
    ultima = resumo[resumo["id_tentativa"] == "jr_teste"].sort_values("data_execucao").iloc[-1]
    checar("falha: último log é status_execucao GATE", ultima["tipo_verificacao"] == "status_execucao" and ultima["acao"] == "GATE")
    erro_consulta = detalhe[detalhe["tipo_verificacao"] == "erro_consulta"]
    checar("falha: detalhe erro_consulta traz a mensagem do Athena", len(erro_consulta) and "Simulação de falha" in erro_consulta["detalhe"].iloc[-1])
    faltando = detalhe[detalhe["tipo_verificacao"] == "etapa_nao_concluida"]["detalhe"].iloc[-1]
    checar("falha: lista as etapas que ficaram para trás", "202509_cta17" in faltando and "202509_alertas_pf" in faltando)
    jsons = sorted(glob.glob(f"{BASE}/logs/hml/execucoes/*.json"))
    falha = json.load(open(jsons[-1]))
    checar("falha: JSON da execução com status FALHA e etapa", falha["status"] == "FALHA" and "cta16" in falha["etapa_falha"], falha.get("etapa_falha"))

    # ---------------------------------------------------------------- 6) workgroup que força configuração
    m, ctx = carregar_orquestrador(fake_aws.FakeAthena(workgroup_forca=True))
    try:
        m.main(ARGS_GLUE + ["--AMBIENTE", "hml", "--SAFRA", "202509", "--MODO", "executar"])
        checar("workgroup forçado: para logo no início com mensagem clara", False)
    except m.ErroExecucao as e:
        checar("workgroup forçado: para logo no início com mensagem clara", "Override client-side settings" in str(e))

    falhas = [n for n, ok, _ in resultados if not ok]
    print(f"\n{len(resultados) - len(falhas)}/{len(resultados)} verificações OK")
    if falhas:
        print("Falharam:", falhas)
        sys.exit(1)


if __name__ == "__main__":
    main()
