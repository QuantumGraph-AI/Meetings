"""Grava os logs com o awswrangler 2.15.1 de verdade (S3 e Glue simulados pelo moto) e lê de volta."""
import os
import sys
from datetime import datetime

os.environ.update(AWS_ACCESS_KEY_ID="teste", AWS_SECRET_ACCESS_KEY="teste", AWS_DEFAULT_REGION="sa-east-1")
import boto3  # noqa: E402
import awswrangler as wr  # noqa: E402
from moto import mock_glue, mock_s3, mock_sts  # noqa: E402

sys.path.insert(0, "/home/claude/entrega/trading_ahead_glue/scripts")
import main_trading_ahead as m  # noqa: E402

BUCKET = "itau-self-wkp-sa-east-1-886436964833"
falhas = []


def checar(nome, ok, detalhe=""):
    print(("OK   " if ok else "FALHOU ") + nome + (f"  [{detalhe}]" if detalhe else ""))
    if not ok:
        falhas.append(nome)


with mock_s3(), mock_glue(), mock_sts():
    boto3.client("s3", region_name="sa-east-1").create_bucket(
        Bucket=BUCKET, CreateBucketConfiguration={"LocationConstraint": "sa-east-1"})
    glue = boto3.client("glue", region_name="sa-east-1")
    glue.create_database(DatabaseInput={"Name": "workspace_db"})
    agora = datetime(2026, 11, 10, 9, 0, tzinfo=m.FUSO_BRASIL)
    cfg = m.configurar(["x", "--AMBIENTE", "hml", "--SAFRA", "202509", "--JOB_RUN_ID", "jr_moto"], agora=agora)
    logs = m.LogBook(cfg, aws=None)
    logs.resumo("inicio_execucao", total=1, etapa="inicializacao")
    logs.resumo("consulta", coluna="cta01", afetados=0, total=1, tolerancia=0.0, etapa="cta01", query_id="q1",
                tempo=1.5, bytes_lidos=123456)
    logs.resumo("volumetria", coluna="workspace_db.hml_cta1_precos_202503", afetados=2484, total=2484, safra="202503")
    logs.detalhe("calibracao_p99", "publico", "PF", {"p99": 73530.0, "cutoff": 100000.0}, publico="PF", etapa="calibracao")
    logs.gravar()
    logs.resumo("status_execucao", total=1, acao="OK", etapa="conclusao")
    logs.gravar()  # segundo lote: append na mesma tabela

    tabela = glue.get_table(DatabaseName="workspace_db", Name="trading_ahead_hml_log_resumo")["Table"]
    tipos = {c["Name"]: c["Type"] for c in tabela["StorageDescriptor"]["Columns"]}
    checar("tabela log_resumo criada no Glue com tipos do padrão original",
           tipos["data_execucao"] == "timestamp" and tipos["n_afetados"] == "bigint" and tipos["pct"] == "double"
           and tipos["bytes_lidos"] == "bigint" and tipos["tempo_total_s"] == "double", str(tipos))
    checar("partição por safra", [p["Name"] for p in tabela["PartitionKeys"]] == ["safra"])
    checar("localização em logs/hml/log_resumo/",
           tabela["StorageDescriptor"]["Location"] == f"s3://{BUCKET}/TRADING_AHEAD/logs/hml/log_resumo/",
           tabela["StorageDescriptor"]["Location"])
    particoes = sorted(p["Values"][0] for p in glue.get_partitions(DatabaseName="workspace_db",
                                                                   TableName="trading_ahead_hml_log_resumo")["Partitions"])
    checar("partições registradas", particoes == ["202503", "202509"], str(particoes))
    df = wr.s3.read_parquet(f"s3://{BUCKET}/TRADING_AHEAD/logs/hml/log_resumo/", dataset=True)
    checar("4 linhas de resumo lidas de volta (2 lotes em append)", len(df) == 4, str(len(df)))
    det = wr.s3.read_parquet(f"s3://{BUCKET}/TRADING_AHEAD/logs/hml/log_detalhe/", dataset=True)
    checar("detalhe com JSON legível", '"p99": 73530.0' in det["detalhe"].iloc[0], det["detalhe"].iloc[0])
    print(df[["safra", "tipo_verificacao", "coluna", "n_afetados", "acao", "etapa", "query_id", "bytes_lidos"]].to_string(index=False))

sys.exit(1 if falhas else 0)
